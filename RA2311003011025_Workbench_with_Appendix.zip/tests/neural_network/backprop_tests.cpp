#include "neural_network/backprop.hpp"

#include <array>
#include <cmath>
#include <iostream>
#include <stdexcept>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

double loss(const uew::neural::Parameters& p) {
    return uew::neural::forward(p, 1.0, 2.0).loss;
}

void test_forward_and_gradient() {
    const uew::neural::Parameters p;
    const auto pass = uew::neural::forward(p, 1.0, 2.0);
    require(std::abs(pass.hidden - std::tanh(0.5)) < 1e-15, "hidden activation mismatch");
    require(std::abs(pass.prediction - pass.hidden) < 1e-15, "output mismatch");
    const auto g = uew::neural::gradients(p, 1.0, 2.0);
    constexpr double epsilon = 1e-6;
    std::array<double, 4> analytic{g.w, g.b, g.v, g.c};
    for (std::size_t i = 0; i < analytic.size(); ++i) {
        auto plus = p;
        auto minus = p;
        double* plus_values[] = {&plus.w, &plus.b, &plus.v, &plus.c};
        double* minus_values[] = {&minus.w, &minus.b, &minus.v, &minus.c};
        *plus_values[i] += epsilon;
        *minus_values[i] -= epsilon;
        const double numeric = (loss(plus) - loss(minus)) / (2.0 * epsilon);
        require(std::abs(analytic[i] - numeric) <= 1e-5, "central finite-difference gradient mismatch");
    }
}

void test_simultaneous_update_and_training() {
    const uew::neural::Parameters p;
    const auto g = uew::neural::gradients(p, 1.0, 2.0);
    const auto updated = uew::neural::gradient_descent_update(p, g, 0.1);
    require(std::abs(updated.w - (p.w - 0.1 * g.w)) < 1e-15, "w update mismatch");
    require(std::abs(updated.b - (p.b - 0.1 * g.b)) < 1e-15, "b update mismatch");
    require(std::abs(updated.v - (p.v - 0.1 * g.v)) < 1e-15, "v update mismatch");
    require(std::abs(updated.c - (p.c - 0.1 * g.c)) < 1e-15, "c update mismatch");
    const auto history = uew::neural::train(p, 1.0, 2.0, 0.1, 100);
    require(history.size() == 101, "expected initial loss plus 100 training steps");
    require(history.front().step == 0 && history.back().step == 100, "training step indices mismatch");
    require(history.back().loss < history.front().loss, "training loss did not decrease");
}

}  // namespace

int main() {
    try {
        test_forward_and_gradient();
        test_simultaneous_update_and_training();
        std::cout << "backprop tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "backprop test failure: " << error.what() << '\n';
        return 1;
    }
}
