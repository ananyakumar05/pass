#include "performance/batch_runner.hpp"

#include <cmath>
#include <iostream>
#include <stdexcept>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

void test_reproducible_cases() {
    const auto a = uew::performance::generate_cases(12, 20, 42);
    const auto b = uew::performance::generate_cases(12, 20, 42);
    require(a.size() == b.size(), "case count differs for repeated seed");
    for (std::size_t i = 0; i < a.size(); ++i) {
        require(a[i].problem.conductivity_W_mK == b[i].problem.conductivity_W_mK, "conductivity generation is not reproducible");
        require(a[i].problem.generation_W_m3 == b[i].problem.generation_W_m3, "generation values are not reproducible");
        require(a[i].problem.conductivity_W_mK > 0 && a[i].problem.generation_W_m3 > 0, "generated parameters must be positive");
    }
}

void test_serial_parallel_agreement_and_order() {
    const auto cases = uew::performance::generate_cases(12, 24, 77);
    const auto serial = uew::performance::run_serial(cases);
    for (const std::size_t workers : {1U, 2U, 3U, 4U}) {
        const auto parallel = uew::performance::run_parallel(cases, workers);
        require(parallel.size() == serial.size(), "parallel result count differs");
        for (std::size_t i = 0; i < serial.size(); ++i) {
            require(parallel[i].solution.element_count == cases[i].element_count, "result order changed");
            const auto& a = serial[i].solution.nodal_temperatures_C;
            const auto& b = parallel[i].solution.nodal_temperatures_C;
            for (std::size_t j = 0; j < a.size(); ++j) {
                require(std::abs(a[j] - b[j]) <= 1e-8, "serial/parallel temperature mismatch");
            }
        }
    }
}

void test_invalid_requests() {
    bool caught = false;
    try { (void)uew::performance::generate_cases(0, 10); }
    catch (const std::invalid_argument&) { caught = true; }
    require(caught, "zero case count accepted");
    caught = false;
    try { (void)uew::performance::run_parallel(uew::performance::generate_cases(1, 2), 0); }
    catch (const std::invalid_argument&) { caught = true; }
    require(caught, "zero worker count accepted");
}

void test_benchmark_protocol() {
    const auto cases = uew::performance::generate_cases(5, 8, 2026);
    const auto report = uew::performance::benchmark(cases, {1, 2}, 5);
    require(report.serial.repetitions_milliseconds.size() == 5, "serial benchmark must have five repetitions");
    require(report.parallel.size() == 2, "parallel worker results missing");
    for (const auto& timing : report.parallel) {
        require(timing.repetitions_milliseconds.size() == 5, "parallel benchmark must have five repetitions");
        require(std::isfinite(timing.median_milliseconds) && timing.median_milliseconds > 0.0,
                "parallel median must be a measured positive duration");
        require(std::abs(timing.speedup - report.serial.median_milliseconds / timing.median_milliseconds) < 1e-12,
                "speedup formula mismatch");
        require(std::abs(timing.efficiency - timing.speedup / static_cast<double>(timing.workers)) < 1e-12,
                "efficiency formula mismatch");
    }
    require(report.maximum_temperature_difference_C <= 1e-8, "benchmark agreement exceeds tolerance");
}

}  // namespace

int main() {
    try {
        test_reproducible_cases();
        test_serial_parallel_agreement_and_order();
        test_invalid_requests();
        test_benchmark_protocol();
        std::cout << "performance tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "performance test failure: " << error.what() << '\n';
        return 1;
    }
}
