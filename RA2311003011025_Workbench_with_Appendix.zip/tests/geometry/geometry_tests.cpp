#include "geometry/geometry_parser.hpp"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

template <typename F>
void must_throw(F function, const char* message) {
    try { function(); }
    catch (const std::exception&) { return; }
    throw std::runtime_error(message);
}

void test_stl_parser() {
    std::istringstream valid("solid one\nfacet normal 0 0 1\nouter loop\nvertex 0 0 0\nvertex 1 0 0\nvertex 0 1 0\nendloop\nendfacet\nendsolid one\n");
    const auto mesh = uew::geometry::parse_ascii_stl(valid);
    require(mesh.name == "one" && mesh.triangles.size() == 1, "valid STL was not parsed");
    require(mesh.triangles[0].vertices[2].y == 1.0, "STL vertex was not preserved");

    std::istringstream malformed("solid x\nfacet normal 0 0 1\nouter loop extra\nendsolid x\n");
    must_throw([&] { (void)uew::geometry::parse_ascii_stl(malformed); }, "malformed STL accepted");
    std::istringstream empty;
    must_throw([&] { (void)uew::geometry::parse_ascii_stl(empty); }, "empty STL accepted");
    std::istringstream nonfinite("solid x\nfacet normal nan 0 1\nouter loop\nvertex 0 0 0\nvertex 1 0 0\nvertex 0 1 0\nendloop\nendfacet\nendsolid x\n");
    must_throw([&] { (void)uew::geometry::parse_ascii_stl(nonfinite); }, "non-finite STL accepted");
}

void test_temperature_csv() {
    std::istringstream valid("node_id,x_m,y_m,z_m,temperature_C\n1,0,0,0,20\n2,0.1,0,0,85.5\n");
    const auto nodes = uew::geometry::parse_temperature_csv(valid);
    require(nodes.size() == 2 && nodes[1].node_id == 2, "valid CSV was not parsed");
    require(nodes[1].temperature_C == 85.5 && nodes[1].position_m.x == 0.1, "CSV values were not preserved");

    std::istringstream bad_header("id,x,y,z,t\n1,0,0,0,20\n");
    must_throw([&] { (void)uew::geometry::parse_temperature_csv(bad_header); }, "malformed CSV header accepted");
    std::istringstream bad_row("node_id,x_m,y_m,z_m,temperature_C\n1,0,0,20\n");
    must_throw([&] { (void)uew::geometry::parse_temperature_csv(bad_row); }, "short CSV row accepted");
    std::istringstream nonfinite("node_id,x_m,y_m,z_m,temperature_C\n1,0,0,0,inf\n");
    must_throw([&] { (void)uew::geometry::parse_temperature_csv(nonfinite); }, "non-finite CSV value accepted");
    std::istringstream empty;
    must_throw([&] { (void)uew::geometry::parse_temperature_csv(empty); }, "empty CSV accepted");
    std::istringstream header_only("node_id,x_m,y_m,z_m,temperature_C\n");
    must_throw([&] { (void)uew::geometry::parse_temperature_csv(header_only); }, "header-only CSV accepted");
}

void test_file_size_limit() {
    const auto path = std::filesystem::temp_directory_path() / "uew_geometry_oversize_test.stl";
    {
        std::ofstream file(path, std::ios::binary | std::ios::trunc);
        file.seekp(static_cast<std::streamoff>(uew::geometry::max_input_bytes));
        file.put('\0');
    }
    must_throw([&] { (void)uew::geometry::load_ascii_stl(path); }, "oversized STL was not rejected");
    std::filesystem::remove(path);
}

void test_bundled_examples() {
    const auto mesh = uew::geometry::load_ascii_stl("data/geometry/example_tetrahedron_ascii.stl");
    require(mesh.triangles.size() == 4, "bundled STL example did not load");
    const auto nodes = uew::geometry::load_temperature_csv("data/thermal/example_synthetic_nodal_temperatures.csv");
    require(nodes.size() == 5, "bundled CSV example did not load");
}

}  // namespace

int main() {
    try {
        test_stl_parser();
        test_temperature_csv();
        test_file_size_limit();
        test_bundled_examples();
        std::cout << "geometry tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "geometry test failure: " << error.what() << '\n';
        return 1;
    }
}
