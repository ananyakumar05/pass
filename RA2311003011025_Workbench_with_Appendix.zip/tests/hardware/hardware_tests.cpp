#include "hardware/mock_adapters.hpp"

#include <iostream>
#include <stdexcept>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

void test_discovery_and_capabilities() {
    const uew::hardware::MockHardwareSystem system;
    const auto devices = system.discover();
    require(devices.size() == 3, "expected three mock device types");
    require(devices[0].kind == uew::hardware::DeviceKind::Microcontroller, "MCU missing");
    require(devices[1].kind == uew::hardware::DeviceKind::Fpga, "FPGA missing");
    require(devices[2].kind == uew::hardware::DeviceKind::JtagAdapter, "JTAG adapter missing");
    for (const auto& device : devices) require(!device.capabilities.empty(), "device capabilities missing");
}

void test_connection_telemetry_and_disconnect() {
    uew::hardware::MockHardwareSystem system;
    auto& mcu = system.adapter("mcu-nucleo-f446re");
    require(mcu.state() == uew::hardware::ConnectionState::Disconnected, "initial state should be disconnected");
    require(mcu.connect().success, "mock MCU connection failed");
    const auto message = mcu.telemetry();
    require(message.sequence == 1 && message.message.find("SIMULATED") != std::string::npos,
            "mock telemetry missing or not labeled");
    mcu.disconnect();
    require(mcu.state() == uew::hardware::ConnectionState::Disconnected, "disconnect did not update state");
    bool caught = false;
    try { (void)mcu.telemetry(); }
    catch (const std::runtime_error&) { caught = true; }
    require(caught, "telemetry allowed while disconnected");
}

void test_timeout_recovery() {
    uew::hardware::MockHardwareSystem system;
    auto& fpga = system.adapter("fpga-arty-a7-35");
    const auto failed = fpga.connect(true);
    require(!failed.success && failed.recoverable, "timeout should be recoverable");
    require(fpga.state() == uew::hardware::ConnectionState::Disconnected, "timeout should not leave device connected");
    require(fpga.connect().success, "retry after timeout failed");
    require(fpga.telemetry().message.find("SIMULATED") != std::string::npos, "FPGA mock telemetry missing");
}

}  // namespace

int main() {
    try {
        test_discovery_and_capabilities();
        test_connection_telemetry_and_disconnect();
        test_timeout_recovery();
        std::cout << "hardware tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "hardware test failure: " << error.what() << '\n';
        return 1;
    }
}
