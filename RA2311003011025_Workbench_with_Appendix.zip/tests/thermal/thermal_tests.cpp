#include "thermal/thermal_solver.hpp"

#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>

namespace {

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

void test_reference_meshes() {
    const uew::thermal::RodProblem p;
    double previous_error = std::numeric_limits<double>::infinity();
    for (const std::size_t elements : {10U, 20U, 40U, 80U}) {
        const auto s = uew::thermal::solve(p, elements);
        require(s.positions_m.size() == elements + 1, "wrong node count");
        require(s.nodal_temperatures_C.size() == elements + 1, "wrong temperature count");
        require(std::abs(s.nodal_temperatures_C.front() - 100.0) < 1e-12, "left boundary not imposed");
        require(std::abs(s.nodal_temperatures_C.back() - 20.0) < 1e-12, "right boundary not imposed");
        require(s.midpoint_errors.size() == elements, "midpoint error count is not per element");
        const double h = 1.0 / static_cast<double>(elements);
        const double expected_midpoint_error = 10000.0 * h * h / (8.0 * 10.0);
        require(std::abs(s.maximum_midpoint_error_C - expected_midpoint_error) < 1e-10,
                "midpoint interpolation error does not match the quadratic reference");
        require(s.maximum_midpoint_error_C < previous_error, "mesh error did not decrease");
        previous_error = s.maximum_midpoint_error_C;
    }
    require(std::abs(uew::thermal::analytical_temperature(p, 0.0) - 100.0) < 1e-12, "analytical left boundary");
    require(std::abs(uew::thermal::analytical_temperature(p, 1.0) - 20.0) < 1e-12, "analytical right boundary");
    const auto one_element = uew::thermal::solve(p, 1);
    require(std::abs(one_element.nodal_temperatures_C.front() - p.left_temperature_C) < 1e-12,
            "single-element left boundary");
    require(std::abs(one_element.nodal_temperatures_C.back() - p.right_temperature_C) < 1e-12,
            "single-element right boundary");
}

void test_invalid_inputs() {
    bool caught = false;
    try { (void)uew::thermal::solve(uew::thermal::RodProblem{}, 0); }
    catch (const std::invalid_argument&) { caught = true; }
    require(caught, "zero element count was accepted");

    auto invalid = uew::thermal::RodProblem{};
    invalid.conductivity_W_mK = 0.0;
    caught = false;
    try { (void)uew::thermal::solve(invalid, 10); }
    catch (const std::invalid_argument&) { caught = true; }
    require(caught, "zero conductivity was accepted");
}

}  // namespace

int main() {
    try {
        test_reference_meshes();
        test_invalid_inputs();
        std::cout << "thermal tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "thermal test failure: " << error.what() << '\n';
        return 1;
    }
}
