#include "performance/batch_runner.hpp"

#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

std::size_t parse_size(const char* text, const char* name) {
    try {
        const auto value = std::stoull(text);
        if (value == 0) throw std::invalid_argument("zero");
        return static_cast<std::size_t>(value);
    } catch (...) {
        throw std::invalid_argument(std::string(name) + " must be a positive integer.");
    }
}

}  // namespace

int main(int argc, char** argv) {
    try {
        const std::size_t cases_count = argc > 1 ? parse_size(argv[1], "case count") : 200;
        const std::size_t elements = argc > 2 ? parse_size(argv[2], "element count") : 500;
        const std::uint64_t seed = 20261102;
        const std::filesystem::path output = argc > 3 ? argv[3] : "results/csv/performance_benchmark.csv";

        const auto cases = uew::performance::generate_cases(cases_count, elements, seed);
        const auto report = uew::performance::benchmark(cases);
        if (!output.parent_path().empty()) std::filesystem::create_directories(output.parent_path());
        std::ofstream csv(output);
        if (!csv) throw std::runtime_error("Could not create benchmark CSV output.");
        csv << "mode,workers,repetition,case_count,elements,seed,elapsed_ms,median_ms,speedup,efficiency,max_abs_temperature_difference_C\n";
        csv << std::setprecision(12);
        for (std::size_t i = 0; i < report.serial.repetitions_milliseconds.size(); ++i) {
            csv << "serial,1," << i + 1 << ',' << cases_count << ',' << elements << ',' << seed << ','
                << report.serial.repetitions_milliseconds[i] << ',' << report.serial.median_milliseconds
                << ",1,1," << report.maximum_temperature_difference_C << '\n';
        }
        for (const auto& timing : report.parallel) {
            for (std::size_t i = 0; i < timing.repetitions_milliseconds.size(); ++i) {
                csv << "parallel," << timing.workers << ',' << i + 1 << ',' << cases_count << ',' << elements << ',' << seed << ','
                    << timing.repetitions_milliseconds[i] << ',' << timing.median_milliseconds << ','
                    << timing.speedup << ',' << timing.efficiency << ',' << report.maximum_temperature_difference_C << '\n';
            }
        }
        if (!csv) throw std::runtime_error("Failed while writing benchmark CSV.");
        std::cout << "cases=" << cases_count << " elements=" << elements << " seed=" << seed
                  << " logical_cpus=" << uew::performance::logical_cpu_count()
                  << " max_abs_diff_C=" << report.maximum_temperature_difference_C << '\n';
        std::cout << "serial median ms=" << report.serial.median_milliseconds << '\n';
        for (const auto& timing : report.parallel) {
            std::cout << timing.workers << " workers median ms=" << timing.median_milliseconds
                      << " speedup=" << timing.speedup << " efficiency=" << timing.efficiency << '\n';
        }
        std::cout << "wrote " << output.string() << '\n';
        return report.maximum_temperature_difference_C <= 1e-8 ? 0 : 2;
    } catch (const std::exception& error) {
        std::cerr << "benchmark failed: " << error.what() << '\n';
        return 1;
    }
}
