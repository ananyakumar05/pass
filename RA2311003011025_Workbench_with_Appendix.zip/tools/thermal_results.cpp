#include "thermal/thermal_solver.hpp"

#include <array>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

namespace {

constexpr std::array<std::size_t, 4> kMeshes{{10, 20, 40, 80}};

void write_temperature_plot(const std::filesystem::path& path,
                            const uew::thermal::RodProblem& problem,
                            const std::array<uew::thermal::Solution, 4>& solutions) {
    constexpr double width = 960.0;
    constexpr double height = 560.0;
    constexpr double left = 92.0;
    constexpr double right = 34.0;
    constexpr double top = 56.0;
    constexpr double bottom = 76.0;
    constexpr double plot_width = width - left - right;
    constexpr double plot_height = height - top - bottom;
    constexpr double y_max = 200.0;

    std::ofstream svg(path);
    if (!svg) throw std::runtime_error("Could not create the thermal temperature SVG.");
    svg << std::fixed << std::setprecision(2)
        << "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"960\" height=\"560\" viewBox=\"0 0 960 560\">\n"
        << "<rect width=\"100%\" height=\"100%\" fill=\"#ffffff\"/>\n"
        << "<text x=\"480\" y=\"30\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"21\" font-weight=\"600\" fill=\"#142b3b\">1D rod thermal FEM: numerical and analytical temperature</text>\n";
    for (int tick = 0; tick <= 200; tick += 40) {
        const double y = top + (y_max - tick) / y_max * plot_height;
        svg << "<line x1=\"" << left << "\" y1=\"" << y << "\" x2=\"" << left + plot_width
            << "\" y2=\"" << y << "\" stroke=\"#e4eaee\"/>\n"
            << "<text x=\"" << left - 12 << "\" y=\"" << y + 5
            << "\" text-anchor=\"end\" font-family=\"Arial,sans-serif\" font-size=\"13\" fill=\"#526775\">"
            << tick << "</text>\n";
    }
    for (int tick = 0; tick <= 10; ++tick) {
        const double x = left + static_cast<double>(tick) / 10.0 * plot_width;
        svg << "<line x1=\"" << x << "\" y1=\"" << top + plot_height << "\" x2=\"" << x
            << "\" y2=\"" << top + plot_height + 5 << "\" stroke=\"#526775\"/>\n"
            << "<text x=\"" << x << "\" y=\"" << top + plot_height + 23
            << "\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"12\" fill=\"#526775\">"
            << (tick / 10.0) << "</text>\n";
    }
    svg << "<line x1=\"" << left << "\" y1=\"" << top << "\" x2=\"" << left
        << "\" y2=\"" << top + plot_height << "\" stroke=\"#526775\" stroke-width=\"1.4\"/>\n"
        << "<line x1=\"" << left << "\" y1=\"" << top + plot_height << "\" x2=\"" << left + plot_width
        << "\" y2=\"" << top + plot_height << "\" stroke=\"#526775\" stroke-width=\"1.4\"/>\n"
        << "<text x=\"480\" y=\"535\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"14\" fill=\"#263d4c\">Position x (m)</text>\n"
        << "<text x=\"20\" y=\"280\" text-anchor=\"middle\" transform=\"rotate(-90 20 280)\" font-family=\"Arial,sans-serif\" font-size=\"14\" fill=\"#263d4c\">Temperature (°C)</text>\n";

    const auto px = [&](double x) { return left + x / problem.length_m * plot_width; };
    const auto py = [&](double temperature) { return top + (y_max - temperature) / y_max * plot_height; };
    constexpr std::array<const char*, 4> colors{{"#146e78", "#3978a8", "#8e63a8", "#c57b2a"}};
    for (std::size_t mesh = 0; mesh < solutions.size(); ++mesh) {
        svg << "<polyline fill=\"none\" stroke=\"" << colors[mesh]
            << "\" stroke-width=\"1.6\" stroke-linejoin=\"round\" points=\"";
        const auto& solution = solutions[mesh];
        for (std::size_t i = 0; i < solution.positions_m.size(); ++i)
            svg << px(solution.positions_m[i]) << ',' << py(solution.nodal_temperatures_C[i]) << ' ';
        svg << "\"/>\n";
    }
    svg << "<polyline fill=\"none\" stroke=\"#d64e3e\" stroke-width=\"2.4\" points=\"";
    for (int i = 0; i <= 400; ++i) {
        const double x = problem.length_m * i / 400.0;
        svg << px(x) << ',' << py(uew::thermal::analytical_temperature(problem, x)) << ' ';
    }
    svg << "\"/>\n";
    const std::array<std::string, 5> labels{{"N = 10", "N = 20", "N = 40", "N = 80", "Analytical"}};
    const std::array<const char*, 5> legend_colors{{colors[0], colors[1], colors[2], colors[3], "#d64e3e"}};
    for (std::size_t i = 0; i < labels.size(); ++i) {
        const double x = left + i * 158.0;
        svg << "<line x1=\"" << x << "\" y1=\"" << top - 17 << "\" x2=\"" << x + 20
            << "\" y2=\"" << top - 17 << "\" stroke=\"" << legend_colors[i] << "\" stroke-width=\"2.5\"/>\n"
            << "<text x=\"" << x + 26 << "\" y=\"" << top - 12
            << "\" font-family=\"Arial,sans-serif\" font-size=\"12\" fill=\"#526775\">" << labels[i] << "</text>\n";
    }
    svg << "</svg>\n";
}

void write_convergence_plot(const std::filesystem::path& path,
                            const std::array<uew::thermal::Solution, 4>& solutions) {
    constexpr double width = 760.0;
    constexpr double height = 480.0;
    constexpr double left = 88.0;
    constexpr double right = 30.0;
    constexpr double top = 54.0;
    constexpr double bottom = 72.0;
    constexpr double plot_width = width - left - right;
    constexpr double plot_height = height - top - bottom;
    constexpr double min_log = -2.0;
    constexpr double max_log = 0.5;
    std::ofstream svg(path);
    if (!svg) throw std::runtime_error("Could not create the thermal convergence SVG.");
    svg << std::fixed << std::setprecision(2)
        << "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"760\" height=\"480\" viewBox=\"0 0 760 480\">\n"
        << "<rect width=\"100%\" height=\"100%\" fill=\"#fff\"/>\n"
        << "<text x=\"380\" y=\"30\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"20\" font-weight=\"600\" fill=\"#142b3b\">Midpoint error convergence</text>\n";
    for (int exponent = -2; exponent <= 0; ++exponent) {
        const double y = top + (max_log - exponent) / (max_log - min_log) * plot_height;
        svg << "<line x1=\"" << left << "\" y1=\"" << y << "\" x2=\"" << left + plot_width
            << "\" y2=\"" << y << "\" stroke=\"#e4eaee\"/>\n"
            << "<text x=\"" << left - 10 << "\" y=\"" << y + 5
            << "\" text-anchor=\"end\" font-family=\"Arial,sans-serif\" font-size=\"12\" fill=\"#526775\">10^"
            << exponent << "</text>\n";
    }
    std::array<std::pair<double, double>, 4> points{};
    for (std::size_t i = 0; i < solutions.size(); ++i) {
        const double x = left + static_cast<double>(i) / 3.0 * plot_width;
        const double log_error = std::log10(solutions[i].maximum_midpoint_error_C);
        const double y = top + (max_log - log_error) / (max_log - min_log) * plot_height;
        points[i] = {x, y};
        svg << "<text x=\"" << x << "\" y=\"" << top + plot_height + 24
            << "\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"12\" fill=\"#526775\">"
            << solutions[i].element_count << "</text>\n";
    }
    svg << "<polyline fill=\"none\" stroke=\"#146e78\" stroke-width=\"2.5\" points=\"";
    for (const auto& point : points) svg << point.first << ',' << point.second << ' ';
    svg << "\"/>\n";
    for (std::size_t i = 0; i < points.size(); ++i)
        svg << "<circle cx=\"" << points[i].first << "\" cy=\"" << points[i].second
            << "\" r=\"4\" fill=\"#146e78\"/>\n";
    svg << "<line x1=\"" << left << "\" y1=\"" << top << "\" x2=\"" << left
        << "\" y2=\"" << top + plot_height << "\" stroke=\"#526775\"/>\n"
        << "<line x1=\"" << left << "\" y1=\"" << top + plot_height << "\" x2=\"" << left + plot_width
        << "\" y2=\"" << top + plot_height << "\" stroke=\"#526775\"/>\n"
        << "<text x=\"410\" y=\"448\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"14\" fill=\"#263d4c\">Elements N</text>\n"
        << "<text x=\"22\" y=\"240\" text-anchor=\"middle\" transform=\"rotate(-90 22 240)\" font-family=\"Arial,sans-serif\" font-size=\"14\" fill=\"#263d4c\">Max midpoint absolute error (°C, log scale)</text>\n"
        << "</svg>\n";
}

}  // namespace

int main(int argc, char** argv) {
    try {
        const std::filesystem::path csv_path = argc > 1 ? argv[1] : "results/csv/thermal_fem_results.csv";
        const std::filesystem::path convergence_path = argc > 2 ? argv[2] : "results/plots/thermal_fem_convergence.svg";
        const std::filesystem::path temperature_path = argc > 3 ? argv[3] : "results/plots/thermal_fem_temperature.svg";
        const uew::thermal::RodProblem problem;
        std::array<uew::thermal::Solution, 4> solutions;
        for (std::size_t i = 0; i < kMeshes.size(); ++i)
            solutions[i] = uew::thermal::solve(problem, kMeshes[i]);

        if (!csv_path.parent_path().empty()) std::filesystem::create_directories(csv_path.parent_path());
        std::ofstream csv(csv_path);
        if (!csv) throw std::runtime_error("Could not create the thermal results CSV.");
        csv << "record_type,elements,x_m,finite_element_temperature_C,analytical_temperature_C,absolute_error_C\n"
            << std::setprecision(15);
        for (const auto& solution : solutions) {
            for (std::size_t i = 0; i < solution.positions_m.size(); ++i) {
                const double x = solution.positions_m[i];
                csv << "node," << solution.element_count << ',' << x << ','
                    << solution.nodal_temperatures_C[i] << ','
                    << uew::thermal::analytical_temperature(problem, x) << ",\n";
            }
            for (const auto& midpoint : solution.midpoint_errors)
                csv << "midpoint," << solution.element_count << ',' << midpoint.position_m << ','
                    << midpoint.finite_element_temperature_C << ',' << midpoint.analytical_temperature_C << ','
                    << midpoint.absolute_error_C << '\n';
        }
        if (!convergence_path.parent_path().empty()) std::filesystem::create_directories(convergence_path.parent_path());
        if (!temperature_path.parent_path().empty()) std::filesystem::create_directories(temperature_path.parent_path());
        write_convergence_plot(convergence_path, solutions);
        write_temperature_plot(temperature_path, problem, solutions);

        std::cout << "elements,max_midpoint_error_C\n" << std::setprecision(12);
        for (const auto& solution : solutions)
            std::cout << solution.element_count << ',' << solution.maximum_midpoint_error_C << '\n';
        std::cout << "Wrote " << csv_path << ", " << convergence_path << ", and " << temperature_path << '\n';
    } catch (const std::exception& error) {
        std::cerr << "thermal result generation failed: " << error.what() << '\n';
        return 1;
    }
}
