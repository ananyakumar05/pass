#include "mainwindow.hpp"
#include "geometry_canvas.hpp"
#include "geometry/geometry_parser.hpp"

#include <QApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QDateTime>
#include <QImage>
#include <QLabel>
#include <QPushButton>
#include <QSpinBox>
#include <QThread>
#include <QWidget>

#include <filesystem>
#include <fstream>
#include <functional>
#include <stdexcept>
#include <string>

namespace fs = std::filesystem;

namespace {

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

void pumpEvents() {
    QApplication::processEvents(QEventLoop::AllEvents, 50);
    QThread::msleep(20);
}

void waitUntil(const std::function<bool()>& predicate, const std::string& description, int timeout_ms = 15000) {
    int elapsed = 0;
    while (!predicate() && elapsed < timeout_ms) {
        pumpEvents();
        elapsed += 20;
    }
    require(predicate(), "Timed out waiting for " + description);
}

QPushButton* button(QWidget& window, const QString& label) {
    for (auto* item : window.findChildren<QPushButton*>())
        if (item->text() == label) return item;
    throw std::runtime_error("Could not find button: " + label.toStdString());
}

QPushButton* navigation(QWidget& window, const QString& label) {
    for (auto* item : window.findChildren<QPushButton*>(QStringLiteral("navButton")))
        if (item->text() == label) return item;
    throw std::runtime_error("Could not find navigation button: " + label.toStdString());
}

bool anyLabelContains(QWidget& window, const QString& fragment) {
    for (auto* item : window.findChildren<QLabel*>())
        if (item->text().contains(fragment, Qt::CaseInsensitive)) return true;
    return false;
}

void capture(QWidget& window, const fs::path& output_dir, std::ofstream& log,
             int index, const std::string& name, const std::string& action) {
    QApplication::processEvents();
    const auto timestamp = QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs).toStdString();
    const fs::path path = output_dir / (std::to_string(index) + "_" + name + ".png");
    require(window.grab().save(QString::fromStdString(path.string()), "PNG"), "Could not save screenshot: " + path.string());
    log << timestamp << " | " << path.filename().string() << " | " << action << "\n";
    log.flush();
}

}  // namespace

int main(int argc, char** argv) {
    QApplication app(argc, argv);
    try {
        require(argc == 3, "Usage: capture_walkthrough <project-root> <output-directory>");
        const fs::path project_root = fs::absolute(argv[1]);
        const fs::path output_dir = fs::absolute(argv[2]);
        fs::create_directories(output_dir);

        const fs::path scratch = fs::temp_directory_path() / "uew-capture-workspace";
        fs::remove_all(scratch);
        fs::create_directories(scratch / "data/geometry");
        fs::create_directories(scratch / "data/thermal");
        fs::copy_file(project_root / "data/geometry/example_tetrahedron_ascii.stl",
                      scratch / "data/geometry/example_tetrahedron_ascii.stl", fs::copy_options::overwrite_existing);
        fs::copy_file(project_root / "data/thermal/example_synthetic_nodal_temperatures.csv",
                      scratch / "data/thermal/example_synthetic_nodal_temperatures.csv", fs::copy_options::overwrite_existing);
        fs::copy(project_root / "results", scratch / "results",
                 fs::copy_options::recursive | fs::copy_options::overwrite_existing);
        fs::create_directories(scratch / "docs/calculations");
        fs::copy_file(project_root / "docs/calculations/thermal_fem.md",
                      scratch / "docs/calculations/thermal_fem.md", fs::copy_options::overwrite_existing);
        fs::current_path(scratch);

        std::ofstream log(output_dir / "walkthrough_log.txt", std::ios::trunc);
        require(static_cast<bool>(log), "Could not create walkthrough log.");
        log << "Qt offscreen screenshot walkthrough. The capture tool exercises compiled UI handlers and the C++ backend.\n"
            << "No physical display or Windows runtime was available; captures are not live Windows screenshots.\n";

        MainWindow window;
        window.resize(1440, 930);
        window.show();
        waitUntil([&] { return window.isVisible(); }, "main window initialization");
        capture(window, output_dir, log, 1, "overview", "Opened the desktop workbench overview.");

        navigation(window, QStringLiteral("Geometry Viewer"))->click();
        pumpEvents();
        auto* canvas = static_cast<GeometryCanvas*>(window.findChild<QWidget*>(QStringLiteral("geometryCanvas")));
        require(canvas != nullptr, "Geometry canvas was not found.");
        window.importStlFile(QString::fromStdString((scratch / "data/geometry/example_tetrahedron_ascii.stl").string()));
        waitUntil([&] { return anyLabelContains(window, QStringLiteral("Loaded example_tetrahedron_ascii.stl")); }, "asynchronous ASCII STL import");
        button(window, QStringLiteral("Fit to view"))->click();
        capture(window, output_dir, log, 2, "geometry_mesh", "Parsed the self-created ASCII STL through the same asynchronous UI import handler and fitted the mesh.");

        window.importTemperatureCsvFile(QString::fromStdString((scratch / "data/thermal/example_synthetic_nodal_temperatures.csv").string()));
        waitUntil([&] { return anyLabelContains(window, QStringLiteral("Loaded example_synthetic_nodal_temperatures.csv")); }, "asynchronous temperature CSV import");
        button(window, QStringLiteral("Fit to view"))->click();
        capture(window, output_dir, log, 3, "geometry_temperature_nodes", "Parsed the explicitly synthetic nodal CSV through the same asynchronous UI import handler and displayed its temperature-colored points.");

        navigation(window, QStringLiteral("Thermal Analysis"))->click();
        button(window, QStringLiteral("Run all four meshes"))->click();
        waitUntil([&] { return anyLabelContains(window, QStringLiteral("Solved all four meshes")); }, "thermal FEM solve and CSV export");
        capture(window, output_dir, log, 4, "thermal_analysis", "Ran the C++ solver for 10, 20, 40, and 80 elements; captured numerical and analytical curves with midpoint errors.");

        navigation(window, QStringLiteral("Performance"))->click();
        auto spinners = window.findChildren<QSpinBox*>();
        require(spinners.size() >= 2, "Performance input controls were not found.");
        spinners[0]->setValue(20);
        spinners[1]->setValue(300);
        button(window, QStringLiteral("Run five-repeat benchmark"))->click();
        waitUntil([&] { return anyLabelContains(window, QStringLiteral("Max temperature difference")); }, "five-repeat serial/parallel benchmark", 30000);
        capture(window, output_dir, log, 5, "performance", "Ran a 20-case by 300-element UI benchmark with five repetitions; timings shown are generated by this walkthrough run.");

        navigation(window, QStringLiteral("Hardware Integration"))->click();
        QCheckBox* timeout_box = nullptr;
        for (auto* item : window.findChildren<QCheckBox*>())
            if (item->text().contains(QStringLiteral("Inject one simulated"))) timeout_box = item;
        require(timeout_box != nullptr, "Hardware timeout control was not found.");
        timeout_box->setChecked(true);
        button(window, QStringLiteral("Connect"))->click();
        waitUntil([&] { return anyLabelContains(window, QStringLiteral("timeout")); }, "recoverable simulated connection timeout");
        capture(window, output_dir, log, 6, "hardware_timeout", "Triggered and displayed the mock adapter's recoverable timeout.");
        button(window, QStringLiteral("Connect"))->click();
        require(anyLabelContains(window, QStringLiteral("Connected")), "Mock adapter retry did not connect.");
        button(window, QStringLiteral("Read telemetry"))->click();
        capture(window, output_dir, log, 7, "hardware_telemetry", "Retried the mock connection and read simulated device telemetry.");

        navigation(window, QStringLiteral("Neural Network"))->click();
        button(window, QStringLiteral("Run 100 training steps"))->click();
        waitUntil([&] { return anyLabelContains(window, QStringLiteral("Loss after 100 steps")); }, "100-step neural-network training");
        capture(window, output_dir, log, 8, "neural_network", "Ran the specified forward pass, gradients, simultaneous update, and 100 training steps.");

        navigation(window, QStringLiteral("Reports & Results"))->click();
        capture(window, output_dir, log, 9, "reports_results", "Opened the results browser after generating current-run exports.");

        log << "Walkthrough complete. Offscreen rendering only; visible display and Windows standalone execution remain unverified.\n";
        window.close();
        fs::remove_all(scratch);
        return 0;
    } catch (const std::exception& error) {
        qCritical("Walkthrough capture failed: %s", error.what());
        return 1;
    }
}
