#include "neural_network/backprop.hpp"

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>

namespace {

void write_loss_svg(const std::filesystem::path& path, const std::vector<uew::neural::TrainingPoint>& history) {
    constexpr double width = 960.0;
    constexpr double height = 560.0;
    constexpr double left = 96.0;
    constexpr double right = 32.0;
    constexpr double top = 64.0;
    constexpr double bottom = 82.0;
    constexpr double plot_width = width - left - right;
    constexpr double plot_height = height - top - bottom;
    constexpr double max_log = 1.0;
    constexpr double min_log = -22.0;
    if (!path.parent_path().empty()) std::filesystem::create_directories(path.parent_path());
    std::ofstream svg(path);
    if (!svg) throw std::runtime_error("Could not create loss plot SVG.");
    svg << "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"960\" height=\"560\" viewBox=\"0 0 960 560\">\n"
        << "<rect width=\"100%\" height=\"100%\" fill=\"#ffffff\"/>\n"
        << "<text x=\"480\" y=\"34\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"22\" font-weight=\"600\" fill=\"#142b3b\">Backpropagation training loss</text>\n";
    for (int exponent = 0; exponent >= -20; exponent -= 4) {
        const double y = top + (max_log - static_cast<double>(exponent)) / (max_log - min_log) * plot_height;
        svg << "<line x1=\"" << left << "\" y1=\"" << y << "\" x2=\"" << left + plot_width
            << "\" y2=\"" << y << "\" stroke=\"#e5ebef\" stroke-width=\"1\"/>\n"
            << "<text x=\"" << left - 12 << "\" y=\"" << y + 5 << "\" text-anchor=\"end\" font-family=\"Arial,sans-serif\" font-size=\"13\" fill=\"#526775\">10^"
            << exponent << "</text>\n";
    }
    for (int tick = 0; tick <= 100; tick += 20) {
        const double x = left + static_cast<double>(tick) / 100.0 * plot_width;
        svg << "<line x1=\"" << x << "\" y1=\"" << top + plot_height << "\" x2=\"" << x
            << "\" y2=\"" << top + plot_height + 5 << "\" stroke=\"#526775\"/>\n"
            << "<text x=\"" << x << "\" y=\"" << top + plot_height + 25
            << "\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"13\" fill=\"#526775\">"
            << tick << "</text>\n";
    }
    svg << "<line x1=\"" << left << "\" y1=\"" << top << "\" x2=\"" << left
        << "\" y2=\"" << top + plot_height << "\" stroke=\"#526775\" stroke-width=\"1.5\"/>\n"
        << "<line x1=\"" << left << "\" y1=\"" << top + plot_height << "\" x2=\"" << left + plot_width
        << "\" y2=\"" << top + plot_height << "\" stroke=\"#526775\" stroke-width=\"1.5\"/>\n"
        << "<text x=\"480\" y=\"530\" text-anchor=\"middle\" font-family=\"Arial,sans-serif\" font-size=\"15\" fill=\"#263d4c\">Training step</text>\n"
        << "<text x=\"24\" y=\"280\" text-anchor=\"middle\" transform=\"rotate(-90 24 280)\" font-family=\"Arial,sans-serif\" font-size=\"15\" fill=\"#263d4c\">Loss J (log scale)</text>\n"
        << "<polyline fill=\"none\" stroke=\"#117b83\" stroke-width=\"3\" stroke-linejoin=\"round\" points=\"";
    for (const auto& point : history) {
        const double x = left + static_cast<double>(point.step) / 100.0 * plot_width;
        const double log_loss = std::log10(std::max(point.loss, 1.0e-22));
        const double y = top + (max_log - log_loss) / (max_log - min_log) * plot_height;
        svg << x << ',' << y << ' ';
    }
    svg << "\"/>\n</svg>\n";
}

}  // namespace

int main(int argc, char** argv) {
    try {
        const std::filesystem::path output = argc > 1 ? argv[1] : "results/csv/backprop_training.csv";
        const std::filesystem::path plot = argc > 2 ? argv[2] : "results/plots/backprop_loss.svg";
        const uew::neural::Parameters initial;
        const auto pass = uew::neural::forward(initial, 1.0, 2.0);
        const auto gradient = uew::neural::gradients(initial, 1.0, 2.0);
        const auto updated = uew::neural::gradient_descent_update(initial, gradient, 0.1);
        const auto history = uew::neural::train(initial, 1.0, 2.0, 0.1, 100);

        if (!output.parent_path().empty()) std::filesystem::create_directories(output.parent_path());
        std::ofstream csv(output);
        if (!csv) throw std::runtime_error("Could not create training CSV output.");
        csv << "step,w,b,v,c,loss\n" << std::setprecision(15);
        for (const auto& point : history) {
            csv << point.step << ',' << point.parameters.w << ',' << point.parameters.b << ','
                << point.parameters.v << ',' << point.parameters.c << ',' << point.loss << '\n';
        }
        write_loss_svg(plot, history);
        std::cout << std::setprecision(12)
                  << "h=" << pass.hidden << " y_hat=" << pass.prediction << " J=" << pass.loss << '\n'
                  << "dJ/dw=" << gradient.w << " dJ/db=" << gradient.b
                  << " dJ/dv=" << gradient.v << " dJ/dc=" << gradient.c << '\n'
                  << "updated w=" << updated.w << " b=" << updated.b
                  << " v=" << updated.v << " c=" << updated.c << '\n'
                  << "loss step 0=" << history.front().loss << " step 100=" << history.back().loss << '\n'
                  << "wrote " << output.string() << " and " << plot.string() << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "backprop demo failed: " << error.what() << '\n';
        return 1;
    }
}
