#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace uew::hardware {

enum class DeviceKind { Microcontroller, Fpga, JtagAdapter };
enum class ConnectionState { Disconnected, Connected };

struct DeviceDescriptor {
    std::string id;
    std::string name;
    DeviceKind kind{};
    std::string host_interface;
    std::string voltage_domain;
    std::vector<std::string> capabilities;
};

struct ConnectResult {
    bool success{};
    bool recoverable{};
    std::string message;
};

struct TelemetryMessage {
    std::string device_id;
    std::size_t sequence{};
    std::string message;
};

class MockDeviceAdapter {
public:
    explicit MockDeviceAdapter(DeviceDescriptor descriptor);

    const DeviceDescriptor& descriptor() const noexcept;
    ConnectionState state() const noexcept;
    ConnectResult connect(bool inject_timeout = false);
    void disconnect() noexcept;
    TelemetryMessage telemetry();

private:
    DeviceDescriptor descriptor_;
    ConnectionState state_{ConnectionState::Disconnected};
    std::size_t telemetry_sequence_{};
};

class MockHardwareSystem {
public:
    MockHardwareSystem();

    std::vector<DeviceDescriptor> discover() const;
    MockDeviceAdapter& adapter(const std::string& id);
    const MockDeviceAdapter& adapter(const std::string& id) const;

private:
    std::vector<MockDeviceAdapter> devices_;
};

const char* to_string(DeviceKind kind) noexcept;
const char* to_string(ConnectionState state) noexcept;

}  // namespace uew::hardware
