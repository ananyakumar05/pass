#include "hardware/mock_adapters.hpp"

#include <stdexcept>
#include <utility>

namespace uew::hardware {

MockDeviceAdapter::MockDeviceAdapter(DeviceDescriptor descriptor)
    : descriptor_(std::move(descriptor)) {}

const DeviceDescriptor& MockDeviceAdapter::descriptor() const noexcept { return descriptor_; }
ConnectionState MockDeviceAdapter::state() const noexcept { return state_; }

ConnectResult MockDeviceAdapter::connect(bool inject_timeout) {
    if (state_ == ConnectionState::Connected) return {true, false, "Already connected (simulated)."};
    if (inject_timeout) return {false, true, "Simulated connection timeout. Retry the connection."};
    state_ = ConnectionState::Connected;
    return {true, false, "Connected (simulated)."};
}

void MockDeviceAdapter::disconnect() noexcept { state_ = ConnectionState::Disconnected; }

TelemetryMessage MockDeviceAdapter::telemetry() {
    if (state_ != ConnectionState::Connected) throw std::runtime_error("Device is disconnected; telemetry is unavailable.");
    ++telemetry_sequence_;
    std::string message;
    switch (descriptor_.kind) {
        case DeviceKind::Microcontroller:
            message = "SIMULATED MCU status: heartbeat=ok, sample=" + std::to_string(telemetry_sequence_);
            break;
        case DeviceKind::Fpga:
            message = "SIMULATED FPGA status: design=ready, sample=" + std::to_string(telemetry_sequence_);
            break;
        case DeviceKind::JtagAdapter:
            message = "SIMULATED JTAG adapter status: target_reference=3.3V, sample=" + std::to_string(telemetry_sequence_);
            break;
    }
    return {descriptor_.id, telemetry_sequence_, std::move(message)};
}

MockHardwareSystem::MockHardwareSystem() {
    devices_.emplace_back(DeviceDescriptor{
        "mcu-nucleo-f446re", "NUCLEO-F446RE (simulated)", DeviceKind::Microcontroller,
        "USB / ST-LINK virtual COM", "3.3 V MCU I/O; USB 5 V input",
        {"device discovery", "connect/disconnect", "simulated heartbeat telemetry"}});
    devices_.emplace_back(DeviceDescriptor{
        "fpga-arty-a7-35", "Arty A7-35 (simulated)", DeviceKind::Fpga,
        "USB J10 (on-board JTAG/UART) or external JTAG at J8", "3.3 V Pmod I/O; USB 5 V input",
        {"device discovery", "connect/disconnect", "simulated design status"}});
    devices_.emplace_back(DeviceDescriptor{
        "jtag-hs2", "Digilent JTAG-HS2 (simulated)", DeviceKind::JtagAdapter,
        "USB micro-AB host link; target-side JTAG header", "target-referenced 1.8-5 V; configured example 3.3 V",
        {"device discovery", "connect/disconnect", "simulated adapter telemetry"}});
}

std::vector<DeviceDescriptor> MockHardwareSystem::discover() const {
    std::vector<DeviceDescriptor> found;
    found.reserve(devices_.size());
    for (const auto& device : devices_) found.push_back(device.descriptor());
    return found;
}

MockDeviceAdapter& MockHardwareSystem::adapter(const std::string& id) {
    for (auto& device : devices_) if (device.descriptor().id == id) return device;
    throw std::out_of_range("Unknown simulated device: " + id);
}

const MockDeviceAdapter& MockHardwareSystem::adapter(const std::string& id) const {
    for (const auto& device : devices_) if (device.descriptor().id == id) return device;
    throw std::out_of_range("Unknown simulated device: " + id);
}

const char* to_string(DeviceKind kind) noexcept {
    switch (kind) {
        case DeviceKind::Microcontroller: return "Microcontroller";
        case DeviceKind::Fpga: return "FPGA";
        case DeviceKind::JtagAdapter: return "JTAG adapter";
    }
    return "Unknown";
}

const char* to_string(ConnectionState state) noexcept {
    return state == ConnectionState::Connected ? "Connected (simulated)" : "Disconnected";
}

}  // namespace uew::hardware
