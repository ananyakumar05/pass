#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <istream>
#include <string>
#include <vector>

namespace uew::geometry {

inline constexpr std::uintmax_t max_input_bytes = 16U * 1024U * 1024U;

struct Point3 {
    double x{};
    double y{};
    double z{};
};

struct Triangle {
    Point3 normal;
    Point3 vertices[3];
};

struct StlMesh {
    std::string name;
    std::vector<Triangle> triangles;
};

struct TemperatureNode {
    std::uint64_t node_id{};
    Point3 position_m;
    double temperature_C{};
};

StlMesh parse_ascii_stl(std::istream& input);
std::vector<TemperatureNode> parse_temperature_csv(std::istream& input);
StlMesh load_ascii_stl(const std::filesystem::path& path);
std::vector<TemperatureNode> load_temperature_csv(const std::filesystem::path& path);

}  // namespace uew::geometry
