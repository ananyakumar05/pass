#include "geometry/geometry_parser.hpp"

#include <cmath>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string_view>
#include <utility>

namespace uew::geometry {
namespace {

std::string trim(std::string text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

std::vector<std::string> words(const std::string& line) {
    std::istringstream stream(line);
    std::vector<std::string> result;
    for (std::string word; stream >> word;) result.push_back(std::move(word));
    return result;
}

double finite_number(const std::string& token, const std::string& context) {
    std::size_t consumed = 0;
    double value = 0.0;
    try {
        value = std::stod(token, &consumed);
    } catch (const std::exception&) {
        throw std::runtime_error(context + " must be a number.");
    }
    if (consumed != token.size() || !std::isfinite(value)) {
        throw std::runtime_error(context + " must be a finite number.");
    }
    return value;
}

std::vector<std::string> csv_fields(const std::string& line) {
    std::vector<std::string> fields;
    std::string field;
    bool quoted = false;
    for (std::size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];
        if (c == '"') {
            if (quoted && i + 1 < line.size() && line[i + 1] == '"') {
                field.push_back('"');
                ++i;
            } else {
                quoted = !quoted;
            }
        } else if (c == ',' && !quoted) {
            fields.push_back(trim(field));
            field.clear();
        } else {
            field.push_back(c);
        }
    }
    if (quoted) throw std::runtime_error("CSV contains an unterminated quoted field.");
    fields.push_back(trim(field));
    return fields;
}

std::uint64_t node_id(const std::string& token, std::size_t line_number) {
    if (token.empty() || token.front() == '-') {
        throw std::runtime_error("CSV line " + std::to_string(line_number) + ": node_id must be a non-negative integer.");
    }
    std::size_t consumed = 0;
    unsigned long long id = 0;
    try { id = std::stoull(token, &consumed); }
    catch (const std::exception&) {
        throw std::runtime_error("CSV line " + std::to_string(line_number) + ": node_id must be an integer.");
    }
    if (consumed != token.size()) {
        throw std::runtime_error("CSV line " + std::to_string(line_number) + ": node_id must be an integer.");
    }
    return static_cast<std::uint64_t>(id);
}

template <typename Parser>
auto load_limited(const std::filesystem::path& path, const char* format, Parser parser)
    -> decltype(parser(std::declval<std::istream&>())) {
    std::error_code error;
    const auto size = std::filesystem::file_size(path, error);
    if (error) throw std::runtime_error(std::string("Cannot read ") + format + " file: " + error.message());
    if (size > max_input_bytes) {
        throw std::runtime_error(std::string(format) + " file exceeds the 16 MiB input limit.");
    }
    std::ifstream stream(path, std::ios::binary);
    if (!stream) throw std::runtime_error(std::string("Cannot open ") + format + " file.");
    return parser(stream);
}

}  // namespace

StlMesh parse_ascii_stl(std::istream& input) {
    StlMesh mesh;
    std::string line;
    std::size_t line_number = 0;
    bool opened = false;
    bool closed = false;

    auto next_line = [&]() -> std::vector<std::string> {
        while (std::getline(input, line)) {
            ++line_number;
            auto tokens = words(line);
            if (!tokens.empty()) return tokens;
        }
        throw std::runtime_error("STL ended unexpectedly near line " + std::to_string(line_number) + ".");
    };
    auto expect = [&](const char* a, const char* b = nullptr) {
        const auto tokens = next_line();
        const std::size_t expected_size = b ? 2U : 1U;
        if (tokens.size() != expected_size || tokens[0] != a || (b && tokens[1] != b)) {
            throw std::runtime_error("Malformed ASCII STL near line " + std::to_string(line_number) + ".");
        }
        return tokens;
    };

    const auto header = next_line();
    if (header[0] != "solid") throw std::runtime_error("ASCII STL must begin with 'solid'.");
    opened = true;
    for (std::size_t i = 1; i < header.size(); ++i) {
        if (i > 1) mesh.name.push_back(' ');
        mesh.name += header[i];
    }

    while (!closed) {
        const auto entry = next_line();
        if (entry[0] == "endsolid") {
            closed = true;
            continue;
        }
        if (entry.size() != 5 || entry[0] != "facet" || entry[1] != "normal") {
            throw std::runtime_error("Expected 'facet normal' near STL line " + std::to_string(line_number) + ".");
        }
        Triangle triangle;
        triangle.normal = {finite_number(entry[2], "STL normal"), finite_number(entry[3], "STL normal"), finite_number(entry[4], "STL normal")};
        expect("outer", "loop");
        for (auto& vertex : triangle.vertices) {
            const auto tokens = next_line();
            if (tokens.size() != 4 || tokens[0] != "vertex") {
                throw std::runtime_error("STL vertex must have three coordinates at line " + std::to_string(line_number) + ".");
            }
            vertex = {finite_number(tokens[1], "STL vertex coordinate"), finite_number(tokens[2], "STL vertex coordinate"), finite_number(tokens[3], "STL vertex coordinate")};
        }
        expect("endloop");
        expect("endfacet");
        mesh.triangles.push_back(triangle);
    }
    if (!opened || mesh.triangles.empty()) throw std::runtime_error("ASCII STL contains no triangles.");
    while (std::getline(input, line)) {
        ++line_number;
        if (!trim(line).empty()) throw std::runtime_error("Unexpected data after 'endsolid' at STL line " + std::to_string(line_number) + ".");
    }
    return mesh;
}

std::vector<TemperatureNode> parse_temperature_csv(std::istream& input) {
    std::string line;
    if (!std::getline(input, line)) throw std::runtime_error("Temperature CSV is empty; expected a header and node rows.");
    const auto header = csv_fields(line);
    const std::vector<std::string> expected{"node_id", "x_m", "y_m", "z_m", "temperature_C"};
    if (header != expected) throw std::runtime_error("Temperature CSV header must be node_id,x_m,y_m,z_m,temperature_C.");

    std::vector<TemperatureNode> nodes;
    std::size_t line_number = 1;
    while (std::getline(input, line)) {
        ++line_number;
        if (trim(line).empty()) throw std::runtime_error("CSV line " + std::to_string(line_number) + " is empty.");
        std::vector<std::string> fields;
        try { fields = csv_fields(line); }
        catch (const std::exception& e) { throw std::runtime_error("CSV line " + std::to_string(line_number) + ": " + e.what()); }
        if (fields.size() != expected.size()) {
            throw std::runtime_error("CSV line " + std::to_string(line_number) + " must contain exactly five columns.");
        }
        try {
            nodes.push_back({node_id(fields[0], line_number),
                             {finite_number(fields[1], "CSV x_m"), finite_number(fields[2], "CSV y_m"), finite_number(fields[3], "CSV z_m")},
                             finite_number(fields[4], "CSV temperature_C")});
        } catch (const std::exception& e) {
            throw std::runtime_error("CSV line " + std::to_string(line_number) + ": " + e.what());
        }
    }
    if (nodes.empty()) throw std::runtime_error("Temperature CSV has a header but no node rows.");
    return nodes;
}

StlMesh load_ascii_stl(const std::filesystem::path& path) {
    return load_limited(path, "ASCII STL", parse_ascii_stl);
}

std::vector<TemperatureNode> load_temperature_csv(const std::filesystem::path& path) {
    return load_limited(path, "temperature CSV", parse_temperature_csv);
}

}  // namespace uew::geometry
