#pragma once

#include "thermal/thermal_solver.hpp"

#include <cstddef>
#include <cstdint>
#include <vector>

namespace uew::performance {

struct BatchCase {
    thermal::RodProblem problem;
    std::size_t element_count{};
};

struct BatchResult {
    thermal::Solution solution;
};

struct TimingSummary {
    std::size_t workers{};
    double median_milliseconds{};
    double speedup{};
    double efficiency{};
    std::vector<double> repetitions_milliseconds;
};

struct BenchmarkResult {
    TimingSummary serial;
    std::vector<TimingSummary> parallel;
    double maximum_temperature_difference_C{};
};

std::vector<BatchCase> generate_cases(std::size_t case_count, std::size_t element_count,
                                      std::uint64_t seed = 20261102);
std::size_t logical_cpu_count() noexcept;
std::vector<BatchResult> run_serial(const std::vector<BatchCase>& cases);
std::vector<BatchResult> run_parallel(const std::vector<BatchCase>& cases, std::size_t requested_workers);
BenchmarkResult benchmark(const std::vector<BatchCase>& cases,
                          const std::vector<std::size_t>& worker_counts = {1, 2, 3, 4},
                          std::size_t repetitions = 5);

}  // namespace uew::performance
