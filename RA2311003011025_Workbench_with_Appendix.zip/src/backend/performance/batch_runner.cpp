#include "performance/batch_runner.hpp"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <exception>
#include <mutex>
#include <random>
#include <stdexcept>
#include <thread>
#include <utility>

namespace uew::performance {
namespace {

std::size_t bounded_workers(std::size_t requested, std::size_t cases) {
    if (requested == 0) throw std::invalid_argument("Worker count must be at least one.");
    const std::size_t cpus = std::max<std::size_t>(1, logical_cpu_count());
    return std::min({requested, cpus, cases});
}

double elapsed_milliseconds(const std::vector<BatchCase>& cases, bool parallel, std::size_t workers) {
    const auto start = std::chrono::steady_clock::now();
    if (parallel) (void)run_parallel(cases, workers);
    else (void)run_serial(cases);
    const auto end = std::chrono::steady_clock::now();
    return std::chrono::duration<double, std::milli>(end - start).count();
}

TimingSummary measure(const std::vector<BatchCase>& cases, bool parallel,
                      std::size_t workers, std::size_t repetitions) {
    TimingSummary summary;
    summary.workers = workers;
    summary.repetitions_milliseconds.reserve(repetitions);
    for (std::size_t i = 0; i < repetitions; ++i) {
        summary.repetitions_milliseconds.push_back(elapsed_milliseconds(cases, parallel, workers));
    }
    auto sorted = summary.repetitions_milliseconds;
    std::sort(sorted.begin(), sorted.end());
    summary.median_milliseconds = sorted[sorted.size() / 2];
    return summary;
}

}  // namespace

std::vector<BatchCase> generate_cases(std::size_t count, std::size_t elements, std::uint64_t seed) {
    if (count == 0) throw std::invalid_argument("Case count must be at least one.");
    if (elements == 0) throw std::invalid_argument("Element count must be at least one.");
    std::mt19937_64 generator(seed);
    std::uniform_real_distribution<double> conductivity(1.0, 100.0);
    std::uniform_real_distribution<double> generation(100.0, 100000.0);
    std::vector<BatchCase> cases;
    cases.reserve(count);
    for (std::size_t i = 0; i < count; ++i) {
        thermal::RodProblem problem;
        problem.conductivity_W_mK = conductivity(generator);
        problem.generation_W_m3 = generation(generator);
        cases.push_back({problem, elements});
    }
    return cases;
}

std::size_t logical_cpu_count() noexcept {
    const unsigned int count = std::thread::hardware_concurrency();
    return count == 0 ? 1U : static_cast<std::size_t>(count);
}

std::vector<BatchResult> run_serial(const std::vector<BatchCase>& cases) {
    if (cases.empty()) throw std::invalid_argument("Batch must contain at least one case.");
    std::vector<BatchResult> results;
    results.reserve(cases.size());
    for (const auto& item : cases) results.push_back({thermal::solve(item.problem, item.element_count)});
    return results;
}

std::vector<BatchResult> run_parallel(const std::vector<BatchCase>& cases, std::size_t requested_workers) {
    if (cases.empty()) throw std::invalid_argument("Batch must contain at least one case.");
    const std::size_t workers = bounded_workers(requested_workers, cases.size());
    std::vector<BatchResult> results(cases.size());
    std::atomic<std::size_t> next{0};
    std::exception_ptr failure;
    std::atomic<bool> failed{false};
    std::vector<std::thread> pool;
    pool.reserve(workers);
    try {
        for (std::size_t worker = 0; worker < workers; ++worker) {
            pool.emplace_back([&] {
                while (!failed.load(std::memory_order_relaxed)) {
                    const std::size_t index = next.fetch_add(1, std::memory_order_relaxed);
                    if (index >= cases.size()) break;
                    try {
                        results[index] = {thermal::solve(cases[index].problem, cases[index].element_count)};
                    } catch (...) {
                        failed.store(true, std::memory_order_relaxed);
                        // Only one worker stores the first exception.
                        static std::mutex exception_mutex;
                        std::lock_guard<std::mutex> lock(exception_mutex);
                        if (!failure) failure = std::current_exception();
                    }
                }
            });
        }
    } catch (...) {
        for (auto& thread : pool) if (thread.joinable()) thread.join();
        throw;
    }
    for (auto& thread : pool) thread.join();
    if (failure) std::rethrow_exception(failure);
    return results;
}

BenchmarkResult benchmark(const std::vector<BatchCase>& cases,
                          const std::vector<std::size_t>& worker_counts,
                          std::size_t repetitions) {
    if (cases.empty()) throw std::invalid_argument("Benchmark workload must contain at least one case.");
    if (repetitions != 5) throw std::invalid_argument("The assessment benchmark requires exactly five measured repetitions.");
    (void)run_serial(cases);  // Warm-up is not included in the measured samples.
    (void)run_parallel(cases, 1);

    BenchmarkResult result;
    result.serial = measure(cases, false, 1, repetitions);
    const auto serial_results = run_serial(cases);
    result.parallel.reserve(worker_counts.size());
    for (const std::size_t requested : worker_counts) {
        const std::size_t actual = bounded_workers(requested, cases.size());
        auto timing = measure(cases, true, actual, repetitions);
        timing.speedup = result.serial.median_milliseconds / timing.median_milliseconds;
        timing.efficiency = timing.speedup / static_cast<double>(actual);
        const auto parallel_results = run_parallel(cases, actual);
        for (std::size_t i = 0; i < cases.size(); ++i) {
            const auto& serial_nodes = serial_results[i].solution.nodal_temperatures_C;
            const auto& parallel_nodes = parallel_results[i].solution.nodal_temperatures_C;
            for (std::size_t j = 0; j < serial_nodes.size(); ++j) {
                result.maximum_temperature_difference_C = std::max(
                    result.maximum_temperature_difference_C, std::abs(serial_nodes[j] - parallel_nodes[j]));
            }
        }
        result.parallel.push_back(std::move(timing));
    }
    return result;
}

}  // namespace uew::performance
