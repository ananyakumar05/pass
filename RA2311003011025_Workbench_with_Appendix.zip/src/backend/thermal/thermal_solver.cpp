#include "thermal/thermal_solver.hpp"

#include <cmath>
#include <stdexcept>
#include <utility>

namespace uew::thermal {
namespace {

void validate(const RodProblem& p, std::size_t elements) {
    if (elements == 0) {
        throw std::invalid_argument("Element count must be greater than zero.");
    }
    if (!std::isfinite(p.length_m) || p.length_m <= 0.0 ||
        !std::isfinite(p.area_m2) || p.area_m2 <= 0.0 ||
        !std::isfinite(p.conductivity_W_mK) || p.conductivity_W_mK <= 0.0 ||
        !std::isfinite(p.generation_W_m3) ||
        !std::isfinite(p.left_temperature_C) ||
        !std::isfinite(p.right_temperature_C)) {
        throw std::invalid_argument("Thermal inputs must be finite; length, area, and conductivity must be positive.");
    }
}

}  // namespace

double analytical_temperature(const RodProblem& p, double x) {
    if (!std::isfinite(x) || x < 0.0 || x > p.length_m) {
        throw std::invalid_argument("Position must be finite and within the rod.");
    }
    const double slope = (p.right_temperature_C - p.left_temperature_C) / p.length_m;
    return p.left_temperature_C + slope * x +
           (p.generation_W_m3 / (2.0 * p.conductivity_W_mK)) * x * (p.length_m - x);
}

Solution solve(const RodProblem& p, std::size_t elements) {
    validate(p, elements);
    const std::size_t nodes = elements + 1;
    const double h = p.length_m / static_cast<double>(elements);
    const double conductance = p.conductivity_W_mK * p.area_m2 / h;
    const double element_load = p.generation_W_m3 * p.area_m2 * h / 2.0;

    // Assemble the tridiagonal global stiffness system and consistent load vector.
    std::vector<double> lower(nodes, 0.0);
    std::vector<double> diagonal(nodes, 0.0);
    std::vector<double> upper(nodes, 0.0);
    std::vector<double> rhs(nodes, 0.0);
    for (std::size_t e = 0; e < elements; ++e) {
        diagonal[e] += conductance;
        diagonal[e + 1] += conductance;
        upper[e] -= conductance;
        lower[e + 1] -= conductance;
        rhs[e] += element_load;
        rhs[e + 1] += element_load;
    }

    // Apply prescribed temperatures by eliminating the known end-node values.
    // A single-element mesh has no free interior row, so both endpoints are
    // imposed directly without modifying either boundary equation.
    if (nodes > 2) {
        rhs[1] -= lower[1] * p.left_temperature_C;
        lower[1] = 0.0;
        rhs[nodes - 2] -= upper[nodes - 2] * p.right_temperature_C;
        upper[nodes - 2] = 0.0;
    }
    diagonal.front() = 1.0;
    upper.front() = 0.0;
    rhs.front() = p.left_temperature_C;

    diagonal.back() = 1.0;
    lower.back() = 0.0;
    rhs.back() = p.right_temperature_C;

    // Thomas algorithm for the resulting symmetric tridiagonal system.
    for (std::size_t i = 1; i < nodes; ++i) {
        if (std::abs(diagonal[i - 1]) < 1.0e-30) {
            throw std::runtime_error("Thermal system is singular during forward elimination.");
        }
        const double factor = lower[i] / diagonal[i - 1];
        diagonal[i] -= factor * upper[i - 1];
        rhs[i] -= factor * rhs[i - 1];
    }
    std::vector<double> temperatures(nodes, 0.0);
    temperatures.back() = rhs.back() / diagonal.back();
    for (std::size_t i = nodes - 1; i-- > 0;) {
        temperatures[i] = (rhs[i] - upper[i] * temperatures[i + 1]) / diagonal[i];
    }

    Solution result;
    result.element_count = elements;
    result.positions_m.resize(nodes);
    result.nodal_temperatures_C = std::move(temperatures);
    result.midpoint_errors.reserve(elements);
    for (std::size_t i = 0; i < nodes; ++i) {
        result.positions_m[i] = static_cast<double>(i) * h;
    }
    for (std::size_t e = 0; e < elements; ++e) {
        const double midpoint_x = (static_cast<double>(e) + 0.5) * h;
        const double fe_midpoint = 0.5 * (result.nodal_temperatures_C[e] + result.nodal_temperatures_C[e + 1]);
        const double exact = analytical_temperature(p, midpoint_x);
        const double error = std::abs(fe_midpoint - exact);
        result.midpoint_errors.push_back({midpoint_x, fe_midpoint, exact, error});
        if (error > result.maximum_midpoint_error_C) {
            result.maximum_midpoint_error_C = error;
        }
    }
    return result;
}

}  // namespace uew::thermal
