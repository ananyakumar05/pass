#pragma once

#include <cstddef>
#include <vector>

namespace uew::thermal {

struct RodProblem {
    double length_m{1.0};
    double area_m2{1.0e-4};
    double conductivity_W_mK{10.0};
    double generation_W_m3{10000.0};
    double left_temperature_C{100.0};
    double right_temperature_C{20.0};
};

struct MidpointError {
    double position_m{};
    double finite_element_temperature_C{};
    double analytical_temperature_C{};
    double absolute_error_C{};
};

struct Solution {
    std::size_t element_count{};
    std::vector<double> positions_m;
    std::vector<double> nodal_temperatures_C;
    std::vector<MidpointError> midpoint_errors;
    double maximum_midpoint_error_C{};
};

// Solves -d/dx(k A dT/dx) = q A using uniform two-node linear elements.
Solution solve(const RodProblem& problem, std::size_t element_count);

double analytical_temperature(const RodProblem& problem, double position_m);

}  // namespace uew::thermal
