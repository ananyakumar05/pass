#pragma once

#include <cstddef>
#include <vector>

namespace uew::neural {

struct Parameters {
    double w{0.5};
    double b{0.0};
    double v{1.0};
    double c{0.0};
};

struct ForwardResult {
    double hidden{};
    double prediction{};
    double loss{};
};

struct Gradients {
    double w{};
    double b{};
    double v{};
    double c{};
};

struct TrainingPoint {
    std::size_t step{};
    Parameters parameters;
    double loss{};
};

ForwardResult forward(const Parameters& parameters, double x, double target);
Gradients gradients(const Parameters& parameters, double x, double target);
Parameters gradient_descent_update(const Parameters& parameters, const Gradients& gradient, double learning_rate);
std::vector<TrainingPoint> train(const Parameters& initial, double x, double target,
                                 double learning_rate, std::size_t steps);

}  // namespace uew::neural
