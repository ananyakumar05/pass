#include "neural_network/backprop.hpp"

#include <cmath>
#include <stdexcept>
#include <string>

namespace uew::neural {
namespace {

void require_finite(double value, const char* name) {
    if (!std::isfinite(value)) throw std::invalid_argument(std::string(name) + " must be finite.");
}

void validate(const Parameters& p, double x, double target) {
    require_finite(p.w, "w");
    require_finite(p.b, "b");
    require_finite(p.v, "v");
    require_finite(p.c, "c");
    require_finite(x, "input");
    require_finite(target, "target");
}

}  // namespace

ForwardResult forward(const Parameters& p, double x, double target) {
    validate(p, x, target);
    const double hidden = std::tanh(p.w * x + p.b);
    const double prediction = p.v * hidden + p.c;
    const double error = prediction - target;
    return {hidden, prediction, 0.5 * error * error};
}

Gradients gradients(const Parameters& p, double x, double target) {
    const auto pass = forward(p, x, target);
    const double residual = pass.prediction - target;
    const double hidden_delta = residual * p.v * (1.0 - pass.hidden * pass.hidden);
    return {hidden_delta * x, hidden_delta, residual * pass.hidden, residual};
}

Parameters gradient_descent_update(const Parameters& p, const Gradients& g, double rate) {
    require_finite(rate, "learning rate");
    if (rate <= 0.0) throw std::invalid_argument("Learning rate must be positive.");
    return {p.w - rate * g.w, p.b - rate * g.b, p.v - rate * g.v, p.c - rate * g.c};
}

std::vector<TrainingPoint> train(const Parameters& initial, double x, double target,
                                 double rate, std::size_t steps) {
    if (steps == 0) throw std::invalid_argument("Training step count must be at least one.");
    if (!std::isfinite(rate) || rate <= 0.0) throw std::invalid_argument("Learning rate must be finite and positive.");
    std::vector<TrainingPoint> history;
    history.reserve(steps + 1);
    Parameters current = initial;
    history.push_back({0, current, forward(current, x, target).loss});
    for (std::size_t step = 1; step <= steps; ++step) {
        const auto g = gradients(current, x, target);
        current = gradient_descent_update(current, g, rate);
        history.push_back({step, current, forward(current, x, target).loss});
    }
    return history;
}

}  // namespace uew::neural
