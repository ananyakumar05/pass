#pragma once

#include "geometry/geometry_parser.hpp"

#include <QPoint>
#include <QWidget>

#include <functional>
#include <optional>
#include <vector>

class GeometryCanvas final : public QWidget {
public:
    enum class View { Mesh, TemperatureNodes };

    explicit GeometryCanvas(QWidget* parent = nullptr);
    void setMesh(uew::geometry::StlMesh mesh);
    void setNodes(std::vector<uew::geometry::TemperatureNode> nodes);
    void setView(View view);
    void fitView();
    void setNodeSelectionCallback(std::function<void()> callback);
    QString selectedNodeDescription() const;

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;
    void wheelEvent(QWheelEvent* event) override;

private:
    QPointF project(const uew::geometry::Point3& point) const;
    void chooseNode(const QPoint& location);
    void rebuildBounds();

    uew::geometry::StlMesh mesh_;
    std::vector<uew::geometry::TemperatureNode> nodes_;
    View view_{View::Mesh};
    double rotate_x_{0.55};
    double rotate_y_{-0.65};
    double zoom_{1.0};
    QPointF pan_{0.0, 0.0};
    QPoint last_mouse_;
    Qt::MouseButton drag_button_{Qt::NoButton};
    std::optional<std::size_t> selected_node_;
    uew::geometry::Point3 center_{};
    double extent_{1.0};
    std::function<void()> selection_callback_;
};
