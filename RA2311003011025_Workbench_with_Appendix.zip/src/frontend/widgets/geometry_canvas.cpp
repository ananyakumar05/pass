#include "geometry_canvas.hpp"

#include <QMouseEvent>
#include <QPainter>
#include <QWheelEvent>

#include <algorithm>
#include <cmath>
#include <limits>

GeometryCanvas::GeometryCanvas(QWidget* parent) : QWidget(parent) {
    setMinimumSize(520, 380);
    setMouseTracking(true);
    setFocusPolicy(Qt::StrongFocus);
}

void GeometryCanvas::setMesh(uew::geometry::StlMesh mesh) {
    mesh_ = std::move(mesh);
    rebuildBounds();
    update();
}

void GeometryCanvas::setNodes(std::vector<uew::geometry::TemperatureNode> nodes) {
    nodes_ = std::move(nodes);
    selected_node_.reset();
    rebuildBounds();
    update();
}

void GeometryCanvas::setView(View view) {
    view_ = view;
    selected_node_.reset();
    rebuildBounds();
    update();
}

void GeometryCanvas::setNodeSelectionCallback(std::function<void()> callback) {
    selection_callback_ = std::move(callback);
}

void GeometryCanvas::fitView() {
    rotate_x_ = 0.55;
    rotate_y_ = -0.65;
    zoom_ = 1.0;
    pan_ = QPointF(0.0, 0.0);
    update();
}

QString GeometryCanvas::selectedNodeDescription() const {
    if (!selected_node_ || *selected_node_ >= nodes_.size()) return QStringLiteral("Select a point to inspect its node values.");
    const auto& node = nodes_[*selected_node_];
    return QStringLiteral("Node %1  |  x %2 m  y %3 m  z %4 m  |  %5 °C")
        .arg(static_cast<qulonglong>(node.node_id))
        .arg(node.position_m.x, 0, 'g', 6).arg(node.position_m.y, 0, 'g', 6)
        .arg(node.position_m.z, 0, 'g', 6).arg(node.temperature_C, 0, 'f', 2);
}

QPointF GeometryCanvas::project(const uew::geometry::Point3& point) const {
    const double scale = 0.40 * static_cast<double>(std::min(width(), height())) / extent_ * zoom_;
    const double x = point.x - center_.x;
    const double y = point.y - center_.y;
    const double z = point.z - center_.z;
    const double x1 = x * std::cos(rotate_y_) + z * std::sin(rotate_y_);
    const double z1 = -x * std::sin(rotate_y_) + z * std::cos(rotate_y_);
    const double y2 = y * std::cos(rotate_x_) - z1 * std::sin(rotate_x_);
    return QPointF(width() * 0.5 + pan_.x() + scale * x1,
                   height() * 0.5 + pan_.y() - scale * y2);
}

void GeometryCanvas::rebuildBounds() {
    double min_x = 0, min_y = 0, min_z = 0, max_x = 0, max_y = 0, max_z = 0;
    bool first = true;
    auto include = [&](const uew::geometry::Point3& p) {
        if (first) { min_x = max_x = p.x; min_y = max_y = p.y; min_z = max_z = p.z; first = false; }
        else { min_x = std::min(min_x, p.x); max_x = std::max(max_x, p.x);
               min_y = std::min(min_y, p.y); max_y = std::max(max_y, p.y);
               min_z = std::min(min_z, p.z); max_z = std::max(max_z, p.z); }
    };
    if (view_ == View::Mesh) {
        for (const auto& triangle : mesh_.triangles) for (const auto& vertex : triangle.vertices) include(vertex);
    } else {
        for (const auto& node : nodes_) include(node.position_m);
    }
    if (first) { center_ = {}; extent_ = 1.0; return; }
    center_ = {0.5 * (min_x + max_x), 0.5 * (min_y + max_y), 0.5 * (min_z + max_z)};
    extent_ = std::max({max_x - min_x, max_y - min_y, max_z - min_z, 1.0e-12});
}

void GeometryCanvas::paintEvent(QPaintEvent*) {
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.fillRect(rect(), QColor("#f6f9fb"));
    painter.setPen(QPen(QColor("#dbe4ea"), 1));
    for (int i = 0; i < width(); i += 32) painter.drawLine(i, 0, i, height());
    for (int i = 0; i < height(); i += 32) painter.drawLine(0, i, width(), i);

    if (view_ == View::Mesh) {
        if (mesh_.triangles.empty()) {
            painter.setPen(QColor("#647987"));
            painter.drawText(rect(), Qt::AlignCenter, QStringLiteral("Choose an ASCII STL file to view its triangle mesh."));
            return;
        }
        painter.setPen(QPen(QColor("#176b78"), 1.4));
        painter.setBrush(QColor(23, 107, 120, 34));
        for (const auto& triangle : mesh_.triangles) {
            QPolygonF polygon;
            for (const auto& vertex : triangle.vertices) polygon << project(vertex);
            painter.drawPolygon(polygon);
        }
        painter.setPen(QColor("#526775"));
        painter.drawText(16, 24, QStringLiteral("ASCII STL  ·  %1 triangles").arg(mesh_.triangles.size()));
    } else {
        if (nodes_.empty()) {
            painter.setPen(QColor("#647987"));
            painter.drawText(rect(), Qt::AlignCenter, QStringLiteral("Choose a nodal temperature CSV to view its point cloud."));
            return;
        }
        double minimum = nodes_.front().temperature_C;
        double maximum = minimum;
        for (const auto& node : nodes_) { minimum = std::min(minimum, node.temperature_C); maximum = std::max(maximum, node.temperature_C); }
        for (std::size_t i = 0; i < nodes_.size(); ++i) {
            const auto& node = nodes_[i];
            const double ratio = maximum == minimum ? 0.5 : (node.temperature_C - minimum) / (maximum - minimum);
            const QColor cold(35, 102, 172), hot(190, 48, 56);
            const QColor color(static_cast<int>(cold.red() * (1.0 - ratio) + hot.red() * ratio),
                               static_cast<int>(cold.green() * (1.0 - ratio) + hot.green() * ratio),
                               static_cast<int>(cold.blue() * (1.0 - ratio) + hot.blue() * ratio));
            const QPointF point = project(node.position_m);
            painter.setPen(QPen(i == selected_node_.value_or(nodes_.size()) ? QColor("#132b3a") : Qt::white, 1.4));
            painter.setBrush(color);
            painter.drawEllipse(point, i == selected_node_.value_or(nodes_.size()) ? 7.0 : 5.0,
                                i == selected_node_.value_or(nodes_.size()) ? 7.0 : 5.0);
        }
        painter.setPen(QColor("#526775"));
        painter.drawText(16, 24, QStringLiteral("Synthetic or imported nodal field  ·  %1 nodes").arg(nodes_.size()));
        const QRect legend(width() - 232, 18, 196, 18);
        for (int x = 0; x < legend.width(); ++x) {
            const double ratio = static_cast<double>(x) / std::max(1, legend.width() - 1);
            painter.setPen(QColor(static_cast<int>(35 * (1.0-ratio) + 190 * ratio),
                                  static_cast<int>(102 * (1.0-ratio) + 48 * ratio),
                                  static_cast<int>(172 * (1.0-ratio) + 56 * ratio)));
            painter.drawLine(legend.left() + x, legend.top(), legend.left() + x, legend.bottom());
        }
        painter.setPen(QColor("#526775"));
        painter.drawText(legend.left(), legend.bottom() + 18, QStringLiteral("%1 °C").arg(minimum, 0, 'f', 1));
        painter.drawText(legend.right() - 55, legend.bottom() + 18, QStringLiteral("%1 °C").arg(maximum, 0, 'f', 1));
    }
}

void GeometryCanvas::mousePressEvent(QMouseEvent* event) {
    last_mouse_ = event->pos();
    drag_button_ = event->button();
    if (view_ == View::TemperatureNodes && event->button() == Qt::LeftButton) chooseNode(event->pos());
}

void GeometryCanvas::mouseMoveEvent(QMouseEvent* event) {
    const QPoint delta = event->pos() - last_mouse_;
    if (drag_button_ == Qt::LeftButton && view_ == View::Mesh) {
        rotate_y_ += delta.x() * 0.009;
        rotate_x_ += delta.y() * 0.009;
        update();
    } else if (drag_button_ == Qt::RightButton || (event->buttons() & Qt::MiddleButton)) {
        pan_ += QPointF(delta);
        update();
    }
    last_mouse_ = event->pos();
}

void GeometryCanvas::mouseReleaseEvent(QMouseEvent*) { drag_button_ = Qt::NoButton; }

void GeometryCanvas::wheelEvent(QWheelEvent* event) {
    zoom_ = std::clamp(zoom_ * (event->angleDelta().y() > 0 ? 1.12 : 0.89), 0.1, 20.0);
    update();
}

void GeometryCanvas::chooseNode(const QPoint& location) {
    double best = 14.0;
    selected_node_.reset();
    for (std::size_t i = 0; i < nodes_.size(); ++i) {
        const QPointF p = project(nodes_[i].position_m);
        const double distance = std::hypot(p.x() - location.x(), p.y() - location.y());
        if (distance < best) { best = distance; selected_node_ = i; }
    }
    update();
    if (selection_callback_) selection_callback_();
}
