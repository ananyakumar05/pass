#include "mainwindow.hpp"

#include <QApplication>

int main(int argc, char** argv) {
    QApplication application(argc, argv);
    application.setApplicationName(QStringLiteral("Unified Engineering Workbench"));
    application.setOrganizationName(QStringLiteral("Pass Science Works Assessment"));
    MainWindow window;
    window.show();
    return application.exec();
}
