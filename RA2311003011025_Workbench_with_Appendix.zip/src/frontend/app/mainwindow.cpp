#include "mainwindow.hpp"

#include "geometry_canvas.hpp"

#include <QCheckBox>
#include <QComboBox>
#include <QCoreApplication>
#include <QDesktopServices>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QProgressBar>
#include <QPushButton>
#include <QScrollArea>
#include <QSpinBox>
#include <QStackedWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QTextStream>
#include <QVBoxLayout>
#include <QDir>
#include <QFutureWatcher>
#include <QFileDialog>
#include <QHeaderView>
#include <QFrame>
#include <QAbstractItemView>
#include <QStandardPaths>
#include <QUrl>
#include <QPainter>
#include <QPainterPath>
#include <QPaintEvent>
#include <QFont>

#include <QtConcurrent/QtConcurrentRun>

#include <algorithm>
#include <cmath>
#include <exception>
#include <fstream>
#include <iomanip>
#include <optional>

namespace {

QWidget* makeCard(const QString& title, QVBoxLayout*& content, QWidget* parent = nullptr) {
    auto* frame = new QFrame(parent);
    frame->setObjectName(QStringLiteral("card"));
    content = new QVBoxLayout(frame);
    content->setContentsMargins(20, 18, 20, 20);
    content->setSpacing(12);
    auto* heading = new QLabel(title, frame);
    heading->setObjectName(QStringLiteral("cardHeading"));
    content->addWidget(heading);
    return frame;
}

QLabel* makeHint(const QString& text, QWidget* parent = nullptr) {
    auto* hint = new QLabel(text, parent);
    hint->setObjectName(QStringLiteral("hint"));
    hint->setWordWrap(true);
    return hint;
}

QPushButton* makeButton(const QString& text, QWidget* parent = nullptr) {
    auto* button = new QPushButton(text, parent);
    button->setCursor(Qt::PointingHandCursor);
    return button;
}

template <typename T>
struct AsyncOutcome {
    std::optional<T> value;
    QString error;
};

template <typename Function>
auto runSafely(Function function) -> AsyncOutcome<decltype(function())> {
    try { return {function(), {}}; }
    catch (const std::exception& error) { return {std::nullopt, QString::fromUtf8(error.what())}; }
    catch (...) { return {std::nullopt, QStringLiteral("Unexpected failure. Check the input and try again.")}; }
}

QString formatNumber(double value, int precision = 4) {
    return QString::number(value, 'g', precision);
}

void clearLayoutItems(QLayout* layout) {
    while (auto* item = layout->takeAt(0)) {
        if (auto* widget = item->widget()) delete widget;
        else if (auto* child_layout = item->layout()) clearLayoutItems(child_layout);
        delete item;
    }
}

}  // namespace

class ThermalPlotWidget final : public QWidget {
public:
    explicit ThermalPlotWidget(QWidget* parent = nullptr) : QWidget(parent) { setMinimumHeight(360); }
    void setData(uew::thermal::Solution solution, uew::thermal::RodProblem problem) {
        solution_ = std::move(solution);
        problem_ = problem;
        ready_ = true;
        update();
    }
protected:
    void paintEvent(QPaintEvent*) override {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.fillRect(rect(), Qt::white);
        const QRectF plot(76, 26, width() - 106, height() - 92);
        double temperature_min = std::min(problem_.left_temperature_C, problem_.right_temperature_C);
        double temperature_max = std::max(problem_.left_temperature_C, problem_.right_temperature_C);
        for (int i = 0; i <= 240; ++i) {
            const double x = problem_.length_m * i / 240.0;
            const double exact = uew::thermal::analytical_temperature(problem_, x);
            temperature_min = std::min(temperature_min, exact);
            temperature_max = std::max(temperature_max, exact);
        }
        for (const double value : solution_.nodal_temperatures_C) {
            temperature_min = std::min(temperature_min, value);
            temperature_max = std::max(temperature_max, value);
        }
        const double padding = std::max(1.0, (temperature_max - temperature_min) * 0.05);
        temperature_min = std::floor((temperature_min - padding) / 20.0) * 20.0;
        temperature_max = std::ceil((temperature_max + padding) / 20.0) * 20.0;
        if (temperature_max <= temperature_min) temperature_max = temperature_min + 20.0;
        painter.setPen(QPen(QColor("#dce5eb"), 1));
        for (int i = 0; i <= 4; ++i) {
            const double y = plot.top() + plot.height() * i / 4.0;
            painter.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y));
            const double tick = temperature_max - (temperature_max - temperature_min) * i / 4.0;
            painter.setPen(QColor("#526775"));
            painter.drawText(QRectF(0, y - 9, 66, 18), Qt::AlignRight | Qt::AlignVCenter, QString::number(tick, 'g', 4));
            painter.setPen(QPen(QColor("#dce5eb"), 1));
        }
        painter.setPen(QPen(QColor("#526775"), 1.3));
        painter.drawLine(plot.bottomLeft(), plot.topLeft());
        painter.drawLine(plot.bottomLeft(), plot.bottomRight());
        painter.setFont(QFont(QStringLiteral("Arial"), 9));
        painter.setPen(QColor("#526775"));
        painter.drawText(QRectF(plot.left() - 10, plot.bottom() + 7, 30, 18), Qt::AlignLeft, QStringLiteral("0"));
        painter.drawText(QRectF(plot.right() - 24, plot.bottom() + 7, 35, 18), Qt::AlignRight, QStringLiteral("1"));
        painter.drawText(QRectF(plot.left(), height() - 30, plot.width(), 20), Qt::AlignCenter,
                         QStringLiteral("Position x (m)"));
        painter.save();
        painter.translate(20, plot.center().y());
        painter.rotate(-90);
        painter.drawText(QRectF(-plot.height()/2, -10, plot.height(), 20), Qt::AlignCenter,
                         QStringLiteral("Temperature (°C)"));
        painter.restore();
        if (!ready_) {
            painter.setPen(QColor("#708391"));
            painter.drawText(plot, Qt::AlignCenter, QStringLiteral("Run the analysis to plot the finite-element and analytical curves."));
            return;
        }
        auto map = [&](double x, double temperature) {
            return QPointF(plot.left() + x / problem_.length_m * plot.width(),
                           plot.bottom() - (temperature - temperature_min) / (temperature_max - temperature_min) * plot.height());
        };
        QPainterPath exact;
        for (int i = 0; i <= 240; ++i) {
            const double x = problem_.length_m * i / 240.0;
            const QPointF p = map(x, uew::thermal::analytical_temperature(problem_, x));
            if (i == 0) exact.moveTo(p); else exact.lineTo(p);
        }
        painter.setPen(QPen(QColor("#da6b2e"), 2.2));
        painter.drawPath(exact);
        QPainterPath fe;
        for (std::size_t i = 0; i < solution_.positions_m.size(); ++i) {
            const QPointF p = map(solution_.positions_m[i], solution_.nodal_temperatures_C[i]);
            if (i == 0) fe.moveTo(p); else fe.lineTo(p);
        }
        painter.setPen(QPen(QColor("#146e78"), 1.8));
        painter.drawPath(fe);
        painter.setPen(QColor("#526775"));
        painter.drawText(QRectF(plot.left() + 14, plot.top() + 4, 170, 18), Qt::AlignLeft,
                         QStringLiteral("N = %1 elements").arg(solution_.element_count));
        painter.setPen(QPen(QColor("#146e78"), 2.2));
        painter.drawLine(QPointF(plot.right() - 230, 20), QPointF(plot.right() - 208, 20));
        painter.setPen(QColor("#526775"));
        painter.drawText(QPointF(plot.right() - 202, 24), QStringLiteral("Finite element"));
        painter.setPen(QPen(QColor("#da6b2e"), 2.2));
        painter.drawLine(QPointF(plot.right() - 104, 20), QPointF(plot.right() - 82, 20));
        painter.setPen(QColor("#526775"));
        painter.drawText(QPointF(plot.right() - 76, 24), QStringLiteral("Analytical"));
    }
private:
    bool ready_{};
    uew::thermal::Solution solution_;
    uew::thermal::RodProblem problem_;
};

class PerformancePlotWidget final : public QWidget {
public:
    explicit PerformancePlotWidget(QWidget* parent = nullptr) : QWidget(parent) { setMinimumHeight(300); }
    void setData(double serial, std::vector<uew::performance::TimingSummary> parallel) {
        serial_ms_ = serial;
        parallel_ = std::move(parallel);
        ready_ = true;
        update();
    }
protected:
    void paintEvent(QPaintEvent*) override {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.fillRect(rect(), Qt::white);
        const QRectF plot(70, 24, width() - 98, height() - 76);
        painter.setPen(QPen(QColor("#e1e8ed"), 1));
        painter.drawLine(plot.bottomLeft(), plot.topLeft());
        painter.drawLine(plot.bottomLeft(), plot.bottomRight());
        if (!ready_) {
            painter.setPen(QColor("#708391"));
            painter.drawText(plot, Qt::AlignCenter, QStringLiteral("Run a batch to compare measured serial and parallel times."));
            return;
        }
        double maximum = serial_ms_;
        for (const auto& item : parallel_) maximum = std::max(maximum, item.median_milliseconds);
        maximum = std::max(maximum, 1.0e-9) * 1.15;
        const int count = static_cast<int>(parallel_.size()) + 1;
        const double slot = plot.width() / std::max(1, count);
        const double bar_width = std::min(52.0, slot * 0.48);
        auto drawBar = [&](int index, double value, const QString& label, const QColor& color) {
            const double height = plot.height() * value / maximum;
            const double x = plot.left() + slot * (index + 0.5) - bar_width / 2.0;
            const QRectF bar(x, plot.bottom() - height, bar_width, height);
            painter.setPen(Qt::NoPen);
            painter.setBrush(color);
            painter.drawRoundedRect(bar, 4, 4);
            painter.setPen(QColor("#3e5563"));
            painter.drawText(QRectF(x - 20, bar.top() - 22, bar_width + 40, 18), Qt::AlignCenter,
                             QStringLiteral("%1 ms").arg(value, 0, 'f', 2));
            painter.drawText(QRectF(plot.left() + slot * index, plot.bottom() + 8, slot, 22), Qt::AlignCenter, label);
        };
        drawBar(0, serial_ms_, QStringLiteral("Serial"), QColor("#718694"));
        for (std::size_t i = 0; i < parallel_.size(); ++i)
            drawBar(static_cast<int>(i + 1), parallel_[i].median_milliseconds, QStringLiteral("%1 worker%2").arg(parallel_[i].workers).arg(parallel_[i].workers == 1 ? "" : "s"), QColor("#167d83"));
        painter.setPen(QColor("#657987"));
        painter.drawText(QRectF(0, 3, width(), 18), Qt::AlignCenter, QStringLiteral("Median compute time (ms, lower is faster)"));
    }
private:
    bool ready_{};
    double serial_ms_{};
    std::vector<uew::performance::TimingSummary> parallel_;
};

class LossPlotWidget final : public QWidget {
public:
    explicit LossPlotWidget(QWidget* parent = nullptr) : QWidget(parent) { setMinimumHeight(320); }
    void setData(std::vector<uew::neural::TrainingPoint> history) {
        history_ = std::move(history);
        update();
    }
protected:
    void paintEvent(QPaintEvent*) override {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        painter.fillRect(rect(), Qt::white);
        const QRectF plot(82, 22, width() - 106, height() - 76);
        painter.setPen(QPen(QColor("#e1e8ed"), 1));
        for (int i = 0; i <= 4; ++i) {
            const double y = plot.top() + plot.height() * i / 4.0;
            painter.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y));
        }
        painter.setPen(QPen(QColor("#526775"), 1.2));
        painter.drawLine(plot.bottomLeft(), plot.topLeft());
        painter.drawLine(plot.bottomLeft(), plot.bottomRight());
        painter.setPen(QColor("#526775"));
        painter.drawText(QRectF(plot.left(), height() - 28, plot.width(), 18), Qt::AlignCenter, QStringLiteral("Training step"));
        painter.save();
        painter.translate(18, plot.center().y()); painter.rotate(-90);
        painter.drawText(QRectF(-plot.height()/2, -10, plot.height(), 18), Qt::AlignCenter, QStringLiteral("Loss J (log scale)"));
        painter.restore();
        if (history_.empty()) return;
        QPainterPath path;
        for (std::size_t i = 0; i < history_.size(); ++i) {
            const double x = plot.left() + static_cast<double>(i) / (history_.size() - 1) * plot.width();
            const double lg = std::log10(std::max(history_[i].loss, 1.0e-22));
            const double y = plot.top() + (1.0 - lg) / 23.0 * plot.height();
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        painter.setPen(QPen(QColor("#167d83"), 2.4));
        painter.drawPath(path);
    }
private:
    std::vector<uew::neural::TrainingPoint> history_;
};

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    setWindowTitle(QStringLiteral("Unified Engineering Workbench"));
    resize(1440, 930);
    setMinimumSize(1120, 760);
    setStyleSheet(QStringLiteral(
        "QMainWindow,QWidget#contentRoot{background:#f2f6f8;color:#18303f;}"
        "QFrame#sidebar{background:#102938;border:0;} QLabel#brand{color:#f4f8fa;font-size:17px;font-weight:700;}"
        "QLabel#brandSub{color:#9ab0bd;font-size:11px;} QPushButton#navButton{background:transparent;color:#c5d3da;border:0;text-align:left;padding:12px 14px;border-radius:7px;font-size:14px;}"
        "QPushButton#navButton:hover{background:#1d3c4d;color:white;} QPushButton#navButton:checked{background:#1b5662;color:white;font-weight:600;}"
        "QLabel#pageTitle{font-size:25px;font-weight:700;color:#142d3d;} QLabel#pageSubtitle{font-size:13px;color:#667d8a;}"
        "QFrame#card{background:white;border:1px solid #e0e8ed;border-radius:11px;} QLabel#cardHeading{font-size:15px;font-weight:650;color:#1b3443;}"
        "QLabel#hint{color:#718590;font-size:12px;} QPushButton{background:#edf3f6;color:#1e4856;border:1px solid #d4e0e6;border-radius:7px;padding:9px 13px;font-weight:600;}"
        "QPushButton:hover{background:#dfecef;} QPushButton:disabled{color:#91a1aa;background:#eff3f5;} QPushButton#primary{background:#146e78;color:white;border:0;} QPushButton#primary:hover{background:#0d5c65;}"
        "QLineEdit,QComboBox,QSpinBox{background:white;border:1px solid #d3dee5;border-radius:6px;padding:8px;color:#18303f;}"
        "QTableWidget{background:white;color:#18303f;gridline-color:#e5ebef;border:1px solid #e0e8ed;border-radius:7px;} QTableWidget::item{color:#18303f;} QHeaderView::section{background:#f0f5f7;color:#526775;border:0;padding:7px;font-weight:600;}"
        "QLabel#status{color:#52707f;font-size:12px;} QProgressBar{border:0;background:#e4ecef;border-radius:3px;max-height:5px;} QProgressBar::chunk{background:#167d83;border-radius:3px;}"
    ));

    auto* root = new QWidget(this);
    root->setObjectName(QStringLiteral("contentRoot"));
    auto* horizontal = new QHBoxLayout(root);
    horizontal->setContentsMargins(0, 0, 0, 0);
    horizontal->setSpacing(0);

    auto* sidebar = new QFrame(root);
    sidebar->setObjectName(QStringLiteral("sidebar"));
    sidebar->setFixedWidth(232);
    auto* side = new QVBoxLayout(sidebar);
    side->setContentsMargins(18, 24, 18, 18);
    side->setSpacing(8);
    auto* brand = new QLabel(QStringLiteral("UEW"), sidebar);
    brand->setObjectName(QStringLiteral("brand"));
    auto* brand_sub = new QLabel(QStringLiteral("UNIFIED ENGINEERING\nWORKBENCH"), sidebar);
    brand_sub->setObjectName(QStringLiteral("brandSub"));
    side->addWidget(brand);
    side->addWidget(brand_sub);
    side->addSpacing(22);
    const std::array<QString, 7> labels{QStringLiteral("Overview"), QStringLiteral("Geometry Viewer"), QStringLiteral("Thermal Analysis"), QStringLiteral("Performance"), QStringLiteral("Hardware Integration"), QStringLiteral("Neural Network"), QStringLiteral("Reports & Results")};
    for (int i = 0; i < static_cast<int>(labels.size()); ++i) {
        nav_buttons_[i] = makeButton(labels[i], sidebar);
        nav_buttons_[i]->setObjectName(QStringLiteral("navButton"));
        nav_buttons_[i]->setCheckable(true);
        side->addWidget(nav_buttons_[i]);
        connect(nav_buttons_[i], &QPushButton::clicked, this, [this, i] { navigate(i); });
    }
    side->addStretch(1);
    auto* side_note = new QLabel(QStringLiteral("C++17 COMPUTATION CORE\nOffline-capable desktop workflow"), sidebar);
    side_note->setObjectName(QStringLiteral("brandSub"));
    side_note->setWordWrap(true);
    side->addWidget(side_note);
    horizontal->addWidget(sidebar);

    auto* right = new QWidget(root);
    auto* right_layout = new QVBoxLayout(right);
    right_layout->setContentsMargins(26, 20, 26, 18);
    right_layout->setSpacing(12);
    auto* top = new QHBoxLayout();
    auto* app_title = new QLabel(QStringLiteral("Engineering Workbench"), right);
    app_title->setStyleSheet(QStringLiteral("font-size:14px;font-weight:650;color:#304b5a;"));
    top->addWidget(app_title);
    top->addStretch(1);
    global_status_ = new QLabel(QStringLiteral("Core ready"), right);
    global_status_->setObjectName(QStringLiteral("status"));
    top->addWidget(global_status_);
    right_layout->addLayout(top);
    busy_bar_ = new QProgressBar(right);
    busy_bar_->setTextVisible(false);
    busy_bar_->setRange(0, 1);
    busy_bar_->setValue(0);
    busy_bar_->setMaximumHeight(5);
    right_layout->addWidget(busy_bar_);

    stack_ = new QStackedWidget(right);
    stack_->addWidget(buildDashboard());
    stack_->addWidget(buildGeometryPage());
    stack_->addWidget(buildThermalPage());
    stack_->addWidget(buildPerformancePage());
    stack_->addWidget(buildHardwarePage());
    stack_->addWidget(buildNeuralPage());
    stack_->addWidget(buildReportsPage());
    right_layout->addWidget(stack_, 1);
    horizontal->addWidget(right, 1);
    setCentralWidget(root);
    navigate(0);
}

QWidget* MainWindow::modulePage(const QString& title, const QString& subtitle, QWidget* body) {
    auto* page = new QWidget(this);
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(0, 4, 0, 0);
    layout->setSpacing(15);
    auto* heading = new QLabel(title, page);
    heading->setObjectName(QStringLiteral("pageTitle"));
    auto* sub = new QLabel(subtitle, page);
    sub->setObjectName(QStringLiteral("pageSubtitle"));
    layout->addWidget(heading);
    layout->addWidget(sub);
    layout->addWidget(body, 1);
    return page;
}

void MainWindow::navigate(int index) {
    if (index < 0 || index >= stack_->count()) return;
    stack_->setCurrentIndex(index);
    for (int i = 0; i < static_cast<int>(nav_buttons_.size()); ++i) nav_buttons_[i]->setChecked(i == index);
    if (index == 6) refreshReportFiles();
}

QString MainWindow::projectRoot() const {
    const QString app = QCoreApplication::applicationDirPath();
    if (QDir(app).exists(QStringLiteral("data"))) return app;
    const QString current = QDir::currentPath();
    if (QDir(current).exists(QStringLiteral("data"))) return current;
    return app;
}

QString MainWindow::outputPath(const QString& relative) const {
    return QDir(projectRoot()).filePath(relative);
}

void MainWindow::setBusy(bool busy, const QString& message) {
    global_status_->setText(message);
    busy_bar_->setRange(0, busy ? 0 : 1);
    if (!busy) busy_bar_->setValue(0);
}

QWidget* MainWindow::buildDashboard() {
    auto* body = new QWidget(this);
    auto* layout = new QVBoxLayout(body);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(18);
    auto* intro = new QWidget(body);
    auto* intro_layout = new QVBoxLayout(intro);
    intro_layout->setContentsMargins(0, 4, 0, 0);
    auto* title = new QLabel(QStringLiteral("Unified Engineering Workbench"), intro);
    title->setObjectName(QStringLiteral("pageTitle"));
    auto* subtitle = new QLabel(QStringLiteral("A focused workspace for engineering data, numerical analysis, performance, and device integration."), intro);
    subtitle->setObjectName(QStringLiteral("pageSubtitle"));
    intro_layout->addWidget(title);
    intro_layout->addWidget(subtitle);
    layout->addWidget(intro);

    auto* summary = new QFrame(body);
    summary->setObjectName(QStringLiteral("card"));
    auto* summary_layout = new QHBoxLayout(summary);
    summary_layout->setContentsMargins(20, 16, 20, 16);
    auto* state = new QLabel(QStringLiteral("●  C++17 computation modules available"), summary);
    state->setStyleSheet(QStringLiteral("color:#167d83;font-weight:650;"));
    summary_layout->addWidget(state);
    summary_layout->addStretch(1);
    summary_layout->addWidget(makeHint(QStringLiteral("This build uses simulated hardware adapters."), summary));
    layout->addWidget(summary);

    auto* grid = new QGridLayout();
    grid->setSpacing(14);
    const std::array<QString, 6> cards{QStringLiteral("Geometry Viewer"), QStringLiteral("Thermal Analysis"), QStringLiteral("Performance"), QStringLiteral("Hardware Integration"), QStringLiteral("Neural Network"), QStringLiteral("Reports & Results")};
    const std::array<QString, 6> descriptions{
        QStringLiteral("Inspect ASCII STL surfaces and nodal temperature fields."),
        QStringLiteral("Run the rod FEM solve and compare it with the analytical profile."),
        QStringLiteral("Measure serial and bounded parallel thermal workloads."),
        QStringLiteral("Explore simulated MCU, FPGA, and JTAG adapter workflows."),
        QStringLiteral("Review the forward pass, gradients, update, and training loss."),
        QStringLiteral("Open generated CSV results and calculation artifacts.")};
    const std::array<int, 6> targets{1, 2, 3, 4, 5, 6};
    for (int i = 0; i < 6; ++i) {
        QVBoxLayout* card_layout{};
        QWidget* card = makeCard(cards[i], card_layout, body);
        card_layout->addWidget(makeHint(descriptions[i], card));
        auto* open = makeButton(QStringLiteral("Open module  →"), card);
        open->setObjectName(QStringLiteral("primary"));
        connect(open, &QPushButton::clicked, this, [this, target = targets[i]] { navigate(target); });
        card_layout->addStretch(1);
        card_layout->addWidget(open, 0, Qt::AlignLeft);
        grid->addWidget(card, i / 3, i % 3);
    }
    layout->addLayout(grid);
    layout->addStretch(1);
    return body;
}

QWidget* MainWindow::buildGeometryPage() {
    auto* body = new QWidget(this);
    auto* layout = new QVBoxLayout(body);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(12);
    QVBoxLayout* files_layout{};
    auto* files = makeCard(QStringLiteral("Import geometry or temperature results"), files_layout, body);
    auto* file_row = new QHBoxLayout();
    auto* open_stl = makeButton(QStringLiteral("Open ASCII STL"), files);
    auto* open_csv = makeButton(QStringLiteral("Open temperature CSV"), files);
    geometry_view_ = new QComboBox(files);
    geometry_view_->addItems({QStringLiteral("STL triangle mesh"), QStringLiteral("Temperature point cloud")});
    auto* fit = makeButton(QStringLiteral("Fit to view"), files);
    file_row->addWidget(open_stl);
    file_row->addWidget(open_csv);
    file_row->addSpacing(12);
    file_row->addWidget(new QLabel(QStringLiteral("View"), files));
    file_row->addWidget(geometry_view_);
    file_row->addStretch(1);
    file_row->addWidget(fit);
    files_layout->addLayout(file_row);
    auto* status_row = new QHBoxLayout();
    stl_file_status_ = makeHint(QStringLiteral("No STL loaded"), files);
    csv_file_status_ = makeHint(QStringLiteral("No CSV loaded"), files);
    status_row->addWidget(stl_file_status_, 1);
    status_row->addWidget(csv_file_status_, 1);
    files_layout->addLayout(status_row);
    layout->addWidget(files);

    QVBoxLayout* viewer_layout{};
    auto* viewer = makeCard(QStringLiteral("Interactive 3D view"), viewer_layout, body);
    geometry_canvas_ = new GeometryCanvas(viewer);
    geometry_canvas_->setObjectName(QStringLiteral("geometryCanvas"));
    viewer_layout->addWidget(geometry_canvas_, 1);
    node_selection_ = makeHint(QStringLiteral("Select a point to inspect its node values."), viewer);
    node_selection_->setObjectName(QStringLiteral("status"));
    viewer_layout->addWidget(node_selection_);
    layout->addWidget(viewer, 1);
    connect(geometry_canvas_, &GeometryCanvas::destroyed, this, [] {});
    geometry_canvas_->setNodeSelectionCallback([this] { updateNodeSelection(); });
    connect(geometry_view_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int index) {
        geometry_canvas_->setView(index == 0 ? GeometryCanvas::View::Mesh : GeometryCanvas::View::TemperatureNodes);
        updateNodeSelection();
    });
    connect(fit, &QPushButton::clicked, geometry_canvas_, &GeometryCanvas::fitView);

    connect(open_stl, &QPushButton::clicked, this, [this] {
        const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("Open ASCII STL"), projectRoot(), QStringLiteral("ASCII STL (*.stl);;All files (*)"));
        if (!path.isEmpty()) importStlFile(path);
    });
    connect(open_csv, &QPushButton::clicked, this, [this] {
        const QString path = QFileDialog::getOpenFileName(this, QStringLiteral("Open nodal temperature CSV"), projectRoot(), QStringLiteral("CSV files (*.csv);;All files (*)"));
        if (!path.isEmpty()) importTemperatureCsvFile(path);
    });
    return modulePage(QStringLiteral("Geometry Viewer"), QStringLiteral("Import ASCII STL geometry or an ANSYS-style nodal temperature CSV."), body);
}

void MainWindow::importStlFile(const QString& path) {
    if (path.isEmpty()) return;
    auto* watcher = new QFutureWatcher<AsyncOutcome<uew::geometry::StlMesh>>(this);
    connect(watcher, &QFutureWatcher<AsyncOutcome<uew::geometry::StlMesh>>::finished, this, [this, watcher, path] {
        const auto outcome = watcher->result();
        watcher->deleteLater();
        setBusy(false, QStringLiteral("Core ready"));
        if (!outcome.value) {
            stl_file_status_->setText(QStringLiteral("Import failed: %1").arg(outcome.error));
            return;
        }
        const auto triangles = static_cast<qulonglong>(outcome.value->triangles.size());
        geometry_canvas_->setMesh(std::move(*outcome.value));
        stl_file_status_->setText(QStringLiteral("Loaded %1  ·  %2 triangles").arg(QFileInfo(path).fileName()).arg(triangles));
        geometry_view_->setCurrentIndex(0);
        setBusy(false, QStringLiteral("ASCII STL loaded and validated"));
    });
    setBusy(true, QStringLiteral("Validating ASCII STL…"));
    watcher->setFuture(QtConcurrent::run([path] { return runSafely([&] { return uew::geometry::load_ascii_stl(path.toStdString()); }); }));
}

void MainWindow::importTemperatureCsvFile(const QString& path) {
    if (path.isEmpty()) return;
    auto* watcher = new QFutureWatcher<AsyncOutcome<std::vector<uew::geometry::TemperatureNode>>>(this);
    connect(watcher, &QFutureWatcher<AsyncOutcome<std::vector<uew::geometry::TemperatureNode>>>::finished, this, [this, watcher, path] {
        const auto outcome = watcher->result();
        watcher->deleteLater();
        setBusy(false, QStringLiteral("Core ready"));
        if (!outcome.value) {
            csv_file_status_->setText(QStringLiteral("Import failed: %1").arg(outcome.error));
            return;
        }
        const auto node_count = static_cast<qulonglong>(outcome.value->size());
        geometry_canvas_->setNodes(std::move(*outcome.value));
        csv_file_status_->setText(QStringLiteral("Loaded %1  ·  %2 nodes").arg(QFileInfo(path).fileName()).arg(node_count));
        geometry_view_->setCurrentIndex(1);
        updateNodeSelection();
        setBusy(false, QStringLiteral("Temperature CSV loaded and validated"));
    });
    setBusy(true, QStringLiteral("Validating nodal temperature CSV…"));
    watcher->setFuture(QtConcurrent::run([path] { return runSafely([&] { return uew::geometry::load_temperature_csv(path.toStdString()); }); }));
}

void MainWindow::updateNodeSelection() {
    if (node_selection_) node_selection_->setText(geometry_canvas_->selectedNodeDescription());
}

QWidget* MainWindow::buildThermalPage() {
    auto* body = new QWidget(this);
    auto* layout = new QVBoxLayout(body);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(12);
    QVBoxLayout* config_layout{};
    auto* config = makeCard(QStringLiteral("Rod model and mesh"), config_layout, body);
    auto* row = new QHBoxLayout();
    row->addWidget(new QLabel(QStringLiteral("Elements to display"), config));
    thermal_mesh_ = new QComboBox(config);
    thermal_mesh_->addItems({QStringLiteral("10"), QStringLiteral("20"), QStringLiteral("40"), QStringLiteral("80")});
    row->addWidget(thermal_mesh_);
    auto* run = makeButton(QStringLiteral("Run all four meshes"), config);
    run->setObjectName(QStringLiteral("primary"));
    row->addWidget(run);
    thermal_export_ = makeButton(QStringLiteral("Export results CSV"), config);
    thermal_export_->setEnabled(false);
    row->addWidget(thermal_export_);
    row->addStretch(1);
    config_layout->addLayout(row);
    config_layout->addWidget(makeHint(QStringLiteral("L = 1 m  ·  A = 1e-4 m²  ·  k = 10 W/(m K)  ·  q = 10,000 W/m³  ·  T(0)=100 °C  ·  T(L)=20 °C"), config));
    layout->addWidget(config);

    auto* result_row = new QHBoxLayout();
    QVBoxLayout* plot_layout{};
    auto* plot_card = makeCard(QStringLiteral("Finite-element and analytical temperature"), plot_layout, body);
    thermal_plot_ = new ThermalPlotWidget(plot_card);
    plot_layout->addWidget(thermal_plot_);
    result_row->addWidget(plot_card, 3);
    QVBoxLayout* table_layout{};
    auto* table_card = makeCard(QStringLiteral("Mesh convergence"), table_layout, body);
    thermal_error_table_ = new QTableWidget(0, 2, table_card);
    thermal_error_table_->setHorizontalHeaderLabels({QStringLiteral("Elements"), QStringLiteral("Max midpoint error (°C)")});
    thermal_error_table_->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    thermal_error_table_->verticalHeader()->setVisible(false);
    thermal_error_table_->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table_layout->addWidget(thermal_error_table_);
    result_row->addWidget(table_card, 2);
    layout->addLayout(result_row, 1);
    thermal_status_ = makeHint(QStringLiteral("Ready. Error is evaluated at each element midpoint using FE interpolation."), body);
    layout->addWidget(thermal_status_);

    connect(thermal_mesh_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this](int index) {
        if (index >= 0 && index < static_cast<int>(thermal_results_.size()))
            thermal_plot_->setData(thermal_results_[static_cast<std::size_t>(index)], uew::thermal::RodProblem{});
    });
    connect(thermal_export_, &QPushButton::clicked, this, [this] {
        try {
            exportThermalResults(thermal_results_);
            thermal_status_->setText(QStringLiteral("Exported results/csv/thermal_rod_results.csv"));
        } catch (const std::exception& error) {
            thermal_status_->setText(QStringLiteral("Export failed: %1").arg(QString::fromUtf8(error.what())));
        }
    });
    connect(run, &QPushButton::clicked, this, [this] {
        auto* watcher = new QFutureWatcher<AsyncOutcome<std::vector<uew::thermal::Solution>>>(this);
        connect(watcher, &QFutureWatcher<AsyncOutcome<std::vector<uew::thermal::Solution>>>::finished, this, [this, watcher] {
            auto outcome = watcher->result();
            watcher->deleteLater();
            setBusy(false, QStringLiteral("Core ready"));
            if (!outcome.value) {
                thermal_status_->setText(QStringLiteral("Thermal solve failed: %1").arg(outcome.error));
                return;
            }
            thermal_results_ = std::move(*outcome.value);
            thermal_error_table_->setRowCount(static_cast<int>(thermal_results_.size()));
            for (int i = 0; i < static_cast<int>(thermal_results_.size()); ++i) {
                const auto& solution = thermal_results_[static_cast<std::size_t>(i)];
                thermal_error_table_->setItem(i, 0, new QTableWidgetItem(QString::number(solution.element_count)));
                thermal_error_table_->setItem(i, 1, new QTableWidgetItem(QString::number(solution.maximum_midpoint_error_C, 'g', 8)));
            }
            thermal_mesh_->setCurrentIndex(0);
            thermal_plot_->setData(thermal_results_.front(), uew::thermal::RodProblem{});
            thermal_export_->setEnabled(true);
            try {
                exportThermalResults(thermal_results_);
                thermal_status_->setText(QStringLiteral("Solved all four meshes. Midpoint errors use FE interpolation; CSV exported."));
            } catch (const std::exception& error) {
                thermal_status_->setText(QStringLiteral("Solved successfully; CSV export failed: %1").arg(QString::fromUtf8(error.what())));
            }
            setBusy(false, QStringLiteral("Thermal analysis completed"));
        });
        setBusy(true, QStringLiteral("Solving 10, 20, 40, and 80 element meshes…"));
        watcher->setFuture(QtConcurrent::run([] {
            return runSafely([] {
                std::vector<uew::thermal::Solution> results;
                for (const std::size_t elements : {10U, 20U, 40U, 80U})
                    results.push_back(uew::thermal::solve(uew::thermal::RodProblem{}, elements));
                return results;
            });
        }));
    });
    return modulePage(QStringLiteral("Thermal Analysis"), QStringLiteral("Steady 1D rod FEM with analytical verification and mesh convergence."), body);
}

void MainWindow::exportThermalResults(const std::vector<uew::thermal::Solution>& results) {
    if (results.empty()) throw std::runtime_error("No thermal results are available to export.");
    const QString path = outputPath(QStringLiteral("results/csv/thermal_rod_results.csv"));
    QDir().mkpath(QFileInfo(path).absolutePath());
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
        throw std::runtime_error(file.errorString().toStdString());
    QTextStream out(&file);
    out.setRealNumberPrecision(12);
    out << "mesh_elements,record_type,x_m,finite_element_temperature_C,analytical_temperature_C,absolute_error_C\n";
    const uew::thermal::RodProblem problem;
    for (const auto& solution : results) {
        for (std::size_t i = 0; i < solution.positions_m.size(); ++i) {
            const double exact = uew::thermal::analytical_temperature(problem, solution.positions_m[i]);
            out << solution.element_count << ",node," << solution.positions_m[i] << ','
                << solution.nodal_temperatures_C[i] << ',' << exact << ','
                << std::abs(solution.nodal_temperatures_C[i] - exact) << '\n';
        }
        for (const auto& midpoint : solution.midpoint_errors)
            out << solution.element_count << ",midpoint," << midpoint.position_m << ','
                << midpoint.finite_element_temperature_C << ',' << midpoint.analytical_temperature_C << ','
                << midpoint.absolute_error_C << '\n';
    }
}

QWidget* MainWindow::buildPerformancePage() {
    auto* body = new QWidget(this);
    auto* layout = new QVBoxLayout(body);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(12);
    QVBoxLayout* config_layout{};
    auto* config = makeCard(QStringLiteral("Reproducible workload"), config_layout, body);
    auto* row = new QHBoxLayout();
    row->addWidget(new QLabel(QStringLiteral("Cases"), config));
    performance_case_count_ = new QSpinBox(config);
    performance_case_count_->setRange(1, 5000);
    performance_case_count_->setValue(500);
    row->addWidget(performance_case_count_);
    row->addWidget(new QLabel(QStringLiteral("Elements per case"), config));
    performance_elements_ = new QSpinBox(config);
    performance_elements_->setRange(1, 10000);
    performance_elements_->setValue(1000);
    row->addWidget(performance_elements_);
    auto* run = makeButton(QStringLiteral("Run five-repeat benchmark"), config);
    run->setObjectName(QStringLiteral("primary"));
    row->addWidget(run);
    row->addStretch(1);
    config_layout->addLayout(row);
    config_layout->addWidget(makeHint(QStringLiteral("Fixed seed 20261102. One serial and one parallel warm-up; workers are capped by available logical CPUs."), config));
    layout->addWidget(config);

    auto* results = new QHBoxLayout();
    QVBoxLayout* plot_layout{};
    auto* plot_card = makeCard(QStringLiteral("Measured execution times"), plot_layout, body);
    performance_plot_ = new PerformancePlotWidget(plot_card);
    plot_layout->addWidget(performance_plot_);
    results->addWidget(plot_card, 3);
    QVBoxLayout* table_layout{};
    auto* table_card = makeCard(QStringLiteral("Median, speedup, and efficiency"), table_layout, body);
    performance_table_ = new QTableWidget(0, 5, table_card);
    performance_table_->setHorizontalHeaderLabels({QStringLiteral("Mode"), QStringLiteral("Workers"), QStringLiteral("Median ms"), QStringLiteral("Speedup"), QStringLiteral("Efficiency")});
    performance_table_->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    performance_table_->verticalHeader()->setVisible(false);
    performance_table_->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table_layout->addWidget(performance_table_);
    results->addWidget(table_card, 3);
    layout->addLayout(results, 1);
    performance_status_ = makeHint(QStringLiteral("No benchmark has been run in this session."), body);
    layout->addWidget(performance_status_);

    connect(run, &QPushButton::clicked, this, [this] {
        const std::size_t count = static_cast<std::size_t>(performance_case_count_->value());
        const std::size_t elements = static_cast<std::size_t>(performance_elements_->value());
        constexpr std::uint64_t seed = 20261102;
        auto* watcher = new QFutureWatcher<AsyncOutcome<uew::performance::BenchmarkResult>>(this);
        connect(watcher, &QFutureWatcher<AsyncOutcome<uew::performance::BenchmarkResult>>::finished, this, [this, watcher, count, elements, seed] {
            auto outcome = watcher->result();
            watcher->deleteLater();
            setBusy(false, QStringLiteral("Core ready"));
            if (!outcome.value) {
                performance_status_->setText(QStringLiteral("Benchmark failed: %1").arg(outcome.error));
                return;
            }
            const auto& report = *outcome.value;
            performance_plot_->setData(report.serial.median_milliseconds, report.parallel);
            performance_table_->setRowCount(static_cast<int>(report.parallel.size()) + 1);
            auto setCell = [this](int row_index, int column, const QString& text) {
                performance_table_->setItem(row_index, column, new QTableWidgetItem(text));
            };
            setCell(0, 0, QStringLiteral("Serial")); setCell(0, 1, QStringLiteral("1"));
            setCell(0, 2, QString::number(report.serial.median_milliseconds, 'f', 4));
            setCell(0, 3, QStringLiteral("1.0000")); setCell(0, 4, QStringLiteral("1.0000"));
            for (int i = 0; i < static_cast<int>(report.parallel.size()); ++i) {
                const auto& timing = report.parallel[static_cast<std::size_t>(i)];
                setCell(i + 1, 0, QStringLiteral("Parallel"));
                setCell(i + 1, 1, QString::number(timing.workers));
                setCell(i + 1, 2, QString::number(timing.median_milliseconds, 'f', 4));
                setCell(i + 1, 3, QString::number(timing.speedup, 'f', 4));
                setCell(i + 1, 4, QString::number(timing.efficiency, 'f', 4));
            }
            try {
                exportBenchmarkResults(report, count, elements, seed);
                performance_status_->setText(QStringLiteral("Max temperature difference %1 °C. Raw samples exported; I/O and rendering are outside measured intervals.")
                    .arg(report.maximum_temperature_difference_C, 0, 'g', 4));
            } catch (const std::exception& error) {
                performance_status_->setText(QStringLiteral("Benchmark completed; export failed: %1").arg(QString::fromUtf8(error.what())));
            }
            setBusy(false, QStringLiteral("Benchmark completed"));
        });
        performance_status_->setText(QStringLiteral("Worker creation/join overhead is included in parallel timings."));
        setBusy(true, QStringLiteral("Generating the fixed-seed workload and measuring five repetitions…"));
        watcher->setFuture(QtConcurrent::run([count, elements, seed] {
            return runSafely([&] {
                const auto cases = uew::performance::generate_cases(count, elements, seed);
                return uew::performance::benchmark(cases);
            });
        }));
    });
    return modulePage(QStringLiteral("Performance"), QStringLiteral("Compare identical independent thermal workloads using serial and bounded C++ workers."), body);
}

void MainWindow::exportBenchmarkResults(const uew::performance::BenchmarkResult& result,
                                        std::size_t count, std::size_t elements, std::uint64_t seed) {
    const QString path = outputPath(QStringLiteral("results/csv/performance_benchmark.csv"));
    QDir().mkpath(QFileInfo(path).absolutePath());
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
        throw std::runtime_error(file.errorString().toStdString());
    QTextStream out(&file);
    out.setRealNumberPrecision(12);
    out << "mode,workers,repetition,case_count,elements,seed,elapsed_ms,median_ms,speedup,efficiency,max_abs_temperature_difference_C\n";
    for (std::size_t i = 0; i < result.serial.repetitions_milliseconds.size(); ++i)
        out << "serial,1," << i + 1 << ',' << count << ',' << elements << ',' << seed << ','
            << result.serial.repetitions_milliseconds[i] << ',' << result.serial.median_milliseconds << ",1,1,"
            << result.maximum_temperature_difference_C << '\n';
    for (const auto& timing : result.parallel) for (std::size_t i = 0; i < timing.repetitions_milliseconds.size(); ++i)
        out << "parallel," << timing.workers << ',' << i + 1 << ',' << count << ',' << elements << ',' << seed << ','
            << timing.repetitions_milliseconds[i] << ',' << timing.median_milliseconds << ','
            << timing.speedup << ',' << timing.efficiency << ',' << result.maximum_temperature_difference_C << '\n';
}

QWidget* MainWindow::buildHardwarePage() {
    auto* body = new QWidget(this);
    auto* layout = new QVBoxLayout(body);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(12);
    QVBoxLayout* device_layout{};
    auto* device_card = makeCard(QStringLiteral("Simulated device adapters"), device_layout, body);
    auto* row = new QHBoxLayout();
    hardware_device_ = new QComboBox(device_card);
    for (const auto& device : hardware_system_.discover())
        hardware_device_->addItem(QString::fromStdString(device.name), QString::fromStdString(device.id));
    row->addWidget(hardware_device_, 1);
    auto* connect_button = makeButton(QStringLiteral("Connect"), device_card);
    connect_button->setObjectName(QStringLiteral("primary"));
    auto* disconnect_button = makeButton(QStringLiteral("Disconnect"), device_card);
    auto* telemetry_button = makeButton(QStringLiteral("Read telemetry"), device_card);
    row->addWidget(connect_button);
    row->addWidget(disconnect_button);
    row->addWidget(telemetry_button);
    device_layout->addLayout(row);
    hardware_timeout_ = new QCheckBox(QStringLiteral("Inject one simulated connection timeout"), device_card);
    device_layout->addWidget(hardware_timeout_);
    hardware_capabilities_ = makeHint(QString(), device_card);
    device_layout->addWidget(hardware_capabilities_);
    layout->addWidget(device_card);

    QVBoxLayout* status_layout{};
    auto* status_card = makeCard(QStringLiteral("Connection and telemetry"), status_layout, body);
    hardware_status_ = new QLabel(QStringLiteral("Disconnected. All device behavior in this view is simulated."), status_card);
    hardware_status_->setWordWrap(true);
    hardware_status_->setMinimumHeight(110);
    hardware_status_->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    status_layout->addWidget(hardware_status_);
    layout->addWidget(status_card, 1);
    layout->addWidget(makeHint(QStringLiteral("The JTAG adapter performs target debug/programming duties; it is not a general-purpose compute device."), body));

    connect(hardware_device_, qOverload<int>(&QComboBox::currentIndexChanged), this, [this] { updateHardwareDetails(); });
    connect(connect_button, &QPushButton::clicked, this, [this] {
        auto& device = hardware_system_.adapter(hardware_device_->currentData().toString().toStdString());
        const auto result = device.connect(hardware_timeout_->isChecked());
        if (hardware_timeout_->isChecked()) hardware_timeout_->setChecked(false);
        hardware_status_->setText(QString::fromStdString(result.message));
        hardware_status_->setStyleSheet(result.success ? QStringLiteral("color:#167d83;font-weight:600;") : QStringLiteral("color:#b65040;font-weight:600;"));
        updateHardwareDetails();
    });
    connect(disconnect_button, &QPushButton::clicked, this, [this] {
        auto& device = hardware_system_.adapter(hardware_device_->currentData().toString().toStdString());
        device.disconnect();
        hardware_status_->setText(QStringLiteral("Disconnected (simulated)."));
        hardware_status_->setStyleSheet(QString());
        updateHardwareDetails();
    });
    connect(telemetry_button, &QPushButton::clicked, this, [this] {
        try {
            auto& device = hardware_system_.adapter(hardware_device_->currentData().toString().toStdString());
            const auto message = device.telemetry();
            hardware_status_->setText(QStringLiteral("%1\nSequence %2").arg(QString::fromStdString(message.message)).arg(message.sequence));
        } catch (const std::exception& error) {
            hardware_status_->setText(QStringLiteral("Telemetry unavailable: %1").arg(QString::fromUtf8(error.what())));
        }
    });
    updateHardwareDetails();
    return modulePage(QStringLiteral("Hardware Integration"), QStringLiteral("Explore host-connected MCU, FPGA, and JTAG adapter workflows using explicit mock devices."), body);
}

void MainWindow::updateHardwareDetails() {
    if (!hardware_device_ || !hardware_capabilities_) return;
    const auto id = hardware_device_->currentData().toString().toStdString();
    const auto& adapter = hardware_system_.adapter(id);
    const auto& descriptor = adapter.descriptor();
    QString capabilities;
    for (const auto& item : descriptor.capabilities) {
        if (!capabilities.isEmpty()) capabilities += QStringLiteral("  ·  ");
        capabilities += QString::fromStdString(item);
    }
    hardware_capabilities_->setText(QStringLiteral("%1\nHost interface: %2\nVoltage domain: %3\nCapabilities: %4\nState: %5")
        .arg(QString::fromStdString(descriptor.name), QString::fromStdString(descriptor.host_interface),
             QString::fromStdString(descriptor.voltage_domain), capabilities,
             QString::fromLatin1(uew::hardware::to_string(adapter.state()))));
}

QWidget* MainWindow::buildNeuralPage() {
    auto* body = new QWidget(this);
    auto* layout = new QVBoxLayout(body);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(12);
    QVBoxLayout* config_layout{};
    auto* config = makeCard(QStringLiteral("Single-sample regression"), config_layout, body);
    config_layout->addWidget(makeHint(QStringLiteral("x = 1  ·  target y = 2  ·  h = tanh(wx+b)  ·  prediction = vh+c  ·  J = 0.5(prediction-y)²"), config));
    auto* row = new QHBoxLayout();
    auto* run = makeButton(QStringLiteral("Run 100 training steps"), config);
    run->setObjectName(QStringLiteral("primary"));
    auto* export_button = makeButton(QStringLiteral("Export training CSV"), config);
    export_button->setEnabled(false);
    row->addWidget(run);
    row->addWidget(export_button);
    row->addStretch(1);
    config_layout->addLayout(row);
    layout->addWidget(config);

    auto* result_row = new QHBoxLayout();
    QVBoxLayout* values_layout{};
    auto* values_card = makeCard(QStringLiteral("Forward pass and initial gradients"), values_layout, body);
    neural_values_ = new QLabel(QStringLiteral("Initial parameters: w=0.5, b=0, v=1, c=0\nRun training to calculate the forward pass and gradients."), values_card);
    neural_values_->setObjectName(QStringLiteral("status"));
    neural_values_->setWordWrap(true);
    neural_values_->setMinimumHeight(150);
    values_layout->addWidget(neural_values_);
    result_row->addWidget(values_card, 2);
    QVBoxLayout* plot_layout{};
    auto* plot_card = makeCard(QStringLiteral("Loss over 100 updates"), plot_layout, body);
    loss_plot_ = new LossPlotWidget(plot_card);
    plot_layout->addWidget(loss_plot_);
    result_row->addWidget(plot_card, 3);
    layout->addLayout(result_row, 1);

    auto history = std::make_shared<std::vector<uew::neural::TrainingPoint>>();
    connect(run, &QPushButton::clicked, this, [this, run, export_button, history] {
        run->setEnabled(false);
        setBusy(true, QStringLiteral("Calculating gradients and training the single-sample network…"));
        auto* watcher = new QFutureWatcher<AsyncOutcome<std::vector<uew::neural::TrainingPoint>>>(this);
        connect(watcher, &QFutureWatcher<AsyncOutcome<std::vector<uew::neural::TrainingPoint>>>::finished, this, [this, watcher, run, export_button, history] {
            auto outcome = watcher->result();
            watcher->deleteLater();
            run->setEnabled(true);
            setBusy(false, QStringLiteral("Core ready"));
            if (!outcome.value) {
                neural_values_->setText(QStringLiteral("Training failed: %1").arg(outcome.error));
                return;
            }
            *history = std::move(*outcome.value);
            loss_plot_->setData(*history);
            const uew::neural::Parameters initial;
            const auto forward = uew::neural::forward(initial, 1.0, 2.0);
            const auto gradient = uew::neural::gradients(initial, 1.0, 2.0);
            const auto updated = uew::neural::gradient_descent_update(initial, gradient, 0.1);
            neural_values_->setText(QStringLiteral(
                "h = %1\ny_hat = %2\nInitial loss = %3\n\n∂J/∂w = %4   ∂J/∂b = %5\n∂J/∂v = %6   ∂J/∂c = %7\n\nAfter one simultaneous update (η=0.1):\nw=%8  b=%9  v=%10  c=%11\n\nLoss after 100 steps = %12")
                .arg(formatNumber(forward.hidden, 8), formatNumber(forward.prediction, 8), formatNumber(forward.loss, 8),
                     formatNumber(gradient.w, 8), formatNumber(gradient.b, 8), formatNumber(gradient.v, 8), formatNumber(gradient.c, 8),
                     formatNumber(updated.w, 8), formatNumber(updated.b, 8), formatNumber(updated.v, 8), formatNumber(updated.c, 8),
                     formatNumber(history->back().loss, 5)));
            export_button->setEnabled(true);
            try { exportNeuralResults(*history); }
            catch (const std::exception& error) { neural_values_->setText(neural_values_->text() + QStringLiteral("\nCSV export failed: %1").arg(QString::fromUtf8(error.what()))); }
            setBusy(false, QStringLiteral("Backpropagation calculation completed"));
        });
        watcher->setFuture(QtConcurrent::run([] {
            return runSafely([] { return uew::neural::train(uew::neural::Parameters{}, 1.0, 2.0, 0.1, 100); });
        }));
    });
    connect(export_button, &QPushButton::clicked, this, [this, history] {
        try { exportNeuralResults(*history); }
        catch (const std::exception& error) { QMessageBox::warning(this, QStringLiteral("CSV export"), QString::fromUtf8(error.what())); }
    });
    return modulePage(QStringLiteral("Neural Network"), QStringLiteral("Hand-coded forward propagation, chain-rule gradients, finite-difference verification, and gradient descent."), body);
}

void MainWindow::exportNeuralResults(const std::vector<uew::neural::TrainingPoint>& history) {
    const QString path = outputPath(QStringLiteral("results/csv/backprop_training.csv"));
    QDir().mkpath(QFileInfo(path).absolutePath());
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
        throw std::runtime_error(file.errorString().toStdString());
    QTextStream out(&file);
    out.setRealNumberPrecision(15);
    out << "step,w,b,v,c,loss\n";
    for (const auto& point : history)
        out << point.step << ',' << point.parameters.w << ',' << point.parameters.b << ','
            << point.parameters.v << ',' << point.parameters.c << ',' << point.loss << '\n';
}

QWidget* MainWindow::buildReportsPage() {
    auto* body = new QWidget(this);
    auto* layout = new QVBoxLayout(body);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(12);
    QVBoxLayout* header_layout{};
    auto* card = makeCard(QStringLiteral("Generated results in this project"), header_layout, body);
    auto* refresh = makeButton(QStringLiteral("Refresh results"), card);
    header_layout->addWidget(refresh, 0, Qt::AlignLeft);
    reports_list_ = new QWidget(card);
    reports_list_->setObjectName(QStringLiteral("reportsList"));
    auto* files_layout = new QVBoxLayout(reports_list_);
    files_layout->setContentsMargins(0, 0, 0, 0);
    files_layout->setSpacing(8);
    header_layout->addWidget(reports_list_, 1);
    layout->addWidget(card, 1);
    layout->addWidget(makeHint(QStringLiteral("Only files currently present are offered here. This page does not create evidence or claim that unrun operations have completed."), body));
    connect(refresh, &QPushButton::clicked, this, [this] { refreshReportFiles(); });
    refreshReportFiles();
    return modulePage(QStringLiteral("Reports & Results"), QStringLiteral("Review and open raw calculations and generated artifacts."), body);
}

void MainWindow::refreshReportFiles() {
    if (!reports_list_) return;
    auto* layout = qobject_cast<QVBoxLayout*>(reports_list_->layout());
    if (!layout) return;
    clearLayoutItems(layout);
    const std::array<std::pair<QString, QString>, 6> files{{
        {QStringLiteral("Thermal FEM raw results"), QStringLiteral("results/csv/thermal_rod_results.csv")},
        {QStringLiteral("Thermal FEM mesh and midpoint results"), QStringLiteral("results/csv/thermal_fem_results.csv")},
        {QStringLiteral("Serial/parallel benchmark samples"), QStringLiteral("results/csv/performance_benchmark.csv")},
        {QStringLiteral("Backpropagation training history"), QStringLiteral("results/csv/backprop_training.csv")},
        {QStringLiteral("Backpropagation loss plot"), QStringLiteral("results/plots/backprop_loss.svg")},
        {QStringLiteral("Thermal FEM calculation notes"), QStringLiteral("docs/calculations/thermal_fem.md")}
    }};
    for (const auto& entry : files) {
        auto* row = new QHBoxLayout();
        auto* name = new QLabel(entry.first, reports_list_);
        row->addWidget(name, 1);
        const QString path = outputPath(entry.second);
        if (QFileInfo::exists(path)) {
            auto* open = makeButton(QStringLiteral("Open"), reports_list_);
            connect(open, &QPushButton::clicked, this, [path] { QDesktopServices::openUrl(QUrl::fromLocalFile(path)); });
            row->addWidget(open);
        } else {
            auto* absent = makeHint(QStringLiteral("Not generated yet"), reports_list_);
            row->addWidget(absent);
        }
        layout->addLayout(row);
    }
    layout->addStretch(1);
}
