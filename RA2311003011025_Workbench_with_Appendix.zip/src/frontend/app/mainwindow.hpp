#pragma once

#include "geometry/geometry_parser.hpp"
#include "hardware/mock_adapters.hpp"
#include "neural_network/backprop.hpp"
#include "performance/batch_runner.hpp"
#include "thermal/thermal_solver.hpp"

#include <QMainWindow>

#include <array>
#include <memory>
#include <vector>

class GeometryCanvas;
class ThermalPlotWidget;
class PerformancePlotWidget;
class LossPlotWidget;
class QLabel;
class QStackedWidget;
class QComboBox;
class QProgressBar;
class QTableWidget;
class QLineEdit;
class QSpinBox;
class QPushButton;
class QCheckBox;

class MainWindow final : public QMainWindow {
public:
    explicit MainWindow(QWidget* parent = nullptr);
    void importStlFile(const QString& path);
    void importTemperatureCsvFile(const QString& path);

private:
    QWidget* buildDashboard();
    QWidget* buildGeometryPage();
    QWidget* buildThermalPage();
    QWidget* buildPerformancePage();
    QWidget* buildHardwarePage();
    QWidget* buildNeuralPage();
    QWidget* buildReportsPage();
    QWidget* modulePage(const QString& title, const QString& subtitle, QWidget* body);
    void navigate(int index);
    QString projectRoot() const;
    QString outputPath(const QString& relative) const;
    void setBusy(bool busy, const QString& message);
    void updateNodeSelection();
    void updateHardwareDetails();
    void refreshReportFiles();
    void exportThermalResults(const std::vector<uew::thermal::Solution>& results);
    void exportBenchmarkResults(const uew::performance::BenchmarkResult& result,
                                std::size_t case_count, std::size_t elements, std::uint64_t seed);
    void exportNeuralResults(const std::vector<uew::neural::TrainingPoint>& history);

    QStackedWidget* stack_{};
    QLabel* global_status_{};
    QProgressBar* busy_bar_{};
    std::array<QPushButton*, 7> nav_buttons_{};
    GeometryCanvas* geometry_canvas_{};
    QLabel* node_selection_{};
    QComboBox* geometry_view_{};
    QLabel* stl_file_status_{};
    QLabel* csv_file_status_{};
    QComboBox* thermal_mesh_{};
    ThermalPlotWidget* thermal_plot_{};
    QTableWidget* thermal_error_table_{};
    QLabel* thermal_status_{};
    QPushButton* thermal_export_{};
    std::vector<uew::thermal::Solution> thermal_results_;
    QSpinBox* performance_case_count_{};
    QSpinBox* performance_elements_{};
    PerformancePlotWidget* performance_plot_{};
    QTableWidget* performance_table_{};
    QLabel* performance_status_{};
    QComboBox* hardware_device_{};
    QLabel* hardware_capabilities_{};
    QLabel* hardware_status_{};
    QCheckBox* hardware_timeout_{};
    QLabel* neural_values_{};
    LossPlotWidget* loss_plot_{};
    QWidget* reports_list_{};
    uew::hardware::MockHardwareSystem hardware_system_;
};
