# Windows packaging handoff

`Build-WindowsPackage.ps1` prepares an x64 Visual Studio 2022/Qt 5.15 package candidate. It configures and builds the app and `Launch.exe`, runs CTest, stages the source/data/results/docs, deploys Qt DLLs/plugins with `windeployqt`, then creates `<CandidateId>_Workbench.zip`.

Run it from PowerShell on a Windows 11 x64 development machine with Visual Studio 2022 C++ tools, CMake 3.20+, Qt 5.15 Widgets/Concurrent and `windeployqt.exe` installed:

```powershell
$QtRoot = $env:QTDIR  # Set QTDIR to the selected Qt 5.15 MSVC kit directory.
.\packaging\windows\Build-WindowsPackage.ps1 -CandidateId YOUR_ID -QtRoot $QtRoot
```

This script and the relative-path launcher are source handoff artifacts only. They have not been compiled or run on Windows. Do not distribute the resulting archive until the script succeeds, the package includes the applicable Qt license notices/source obligations, and a clean Windows 11 x64 extraction-and-launch test succeeds. Name the verified ZIP using the assigned candidate ID (currently `RA2311003011025`) and the assessment's required filename pattern.

## Build using GitHub Actions

The project includes `.github/workflows/build-windows.yml`. Upload the project to a GitHub repository, then open **Actions → Build Windows package → Run workflow**. The workflow installs Qt 5.15.2 for the MSVC 2019 x64 ABI on a Windows 2022 runner and calls the packaging script. If the workflow succeeds, download the `RA2311003011025_Workbench_Windows_x64` artifact from that run. It contains the Windows package ZIP; it is a build artifact and still needs a real extraction-and-launch check on Windows 11 before submission.
