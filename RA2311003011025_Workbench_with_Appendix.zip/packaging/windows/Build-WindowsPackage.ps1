param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9_-]+$')]
    [string]$CandidateId,

    [Parameter(Mandatory = $true)]
    [string]$QtRoot
)

$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$QtRoot = (Resolve-Path $QtRoot).Path
$QtDeploy = Join-Path $QtRoot 'bin/windeployqt.exe'
if (-not (Test-Path $QtDeploy)) {
    throw "windeployqt.exe was not found under QtRoot: $QtRoot"
}

$BuildDir = Join-Path $ProjectRoot 'build/windows-x64'
$StageDir = Join-Path $ProjectRoot "build/package/$CandidateId`_Workbench"
$ZipPath = Join-Path $ProjectRoot "build/package/$CandidateId`_Workbench.zip"

cmake -S $ProjectRoot -B $BuildDir -G 'Visual Studio 17 2022' -A x64 "-DCMAKE_PREFIX_PATH=$QtRoot"
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed.' }
cmake --build $BuildDir --config Release --target UnifiedEngineeringWorkbench Launch
if ($LASTEXITCODE -ne 0) { throw 'Application or launcher build failed.' }
ctest --test-dir $BuildDir -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw 'One or more C++ tests failed; packaging stopped.' }

if (Test-Path $StageDir) { Remove-Item $StageDir -Recurse -Force }
New-Item -ItemType Directory -Path $StageDir | Out-Null
$AppExe = Join-Path $BuildDir 'Release/UnifiedEngineeringWorkbench.exe'
$LauncherExe = Join-Path $BuildDir 'Release/Launch.exe'
Copy-Item $AppExe, $LauncherExe -Destination $StageDir
Copy-Item (Join-Path $ProjectRoot 'src'), (Join-Path $ProjectRoot 'tests'),
          (Join-Path $ProjectRoot 'data'), (Join-Path $ProjectRoot 'results'),
          (Join-Path $ProjectRoot 'docs'), (Join-Path $ProjectRoot '.vscode'),
          (Join-Path $ProjectRoot 'tools'), (Join-Path $ProjectRoot 'scripts'),
          (Join-Path $ProjectRoot 'packaging') -Destination $StageDir -Recurse
Copy-Item (Join-Path $ProjectRoot 'CMakeLists.txt'), (Join-Path $ProjectRoot 'README.md'),
          (Join-Path $ProjectRoot 'DEPENDENCIES.md'), (Join-Path $ProjectRoot 'AI_USE_LOG.md'),
          (Join-Path $ProjectRoot 'UnifiedEngineeringWorkbench.pro'),
          (Join-Path $ProjectRoot 'PACKAGING_STATUS.md') -Destination $StageDir
Copy-Item (Join-Path $ProjectRoot 'outputs/Unified_Engineering_Workbench_Technical_Report.pdf') -Destination $StageDir
if (Test-Path (Join-Path $ProjectRoot 'outputs/walkthrough')) {
    Copy-Item (Join-Path $ProjectRoot 'outputs/walkthrough') -Destination $StageDir -Recurse
}
foreach ($EvidenceFile in @('Unified_Engineering_Workbench.bundle', 'GIT_COMMIT_LOG.txt')) {
    $EvidencePath = Join-Path $ProjectRoot "outputs/$EvidenceFile"
    if (Test-Path $EvidencePath) { Copy-Item $EvidencePath -Destination $StageDir }
}

& $QtDeploy --release --no-translations --compiler-runtime $AppExe --dir $StageDir
if ($LASTEXITCODE -ne 0) { throw 'Qt runtime deployment failed.' }

@'
Package verification status: build/test/deployment commands completed on this Windows machine.
Before submission, test extraction and double-click Launch.exe on a clean Windows 11 x64 account without Qt, Visual Studio, administrator rights, or network access. Confirm the required Qt license notices and source availability are present for the selected Qt license.
'@ | Set-Content -Encoding UTF8 (Join-Path $StageDir 'FINAL_STANDALONE_CHECK_REQUIRED.txt')

if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
Compress-Archive -Path (Join-Path $StageDir '*') -DestinationPath $ZipPath -CompressionLevel Optimal
Write-Output "Created package candidate: $ZipPath"
