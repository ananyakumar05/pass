#define NOMINMAX
#include <windows.h>

#include <filesystem>
#include <string>
#include <vector>

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    std::vector<wchar_t> module_path(32768);
    const DWORD length = GetModuleFileNameW(nullptr, module_path.data(), static_cast<DWORD>(module_path.size()));
    if (length == 0 || length >= module_path.size()) {
        MessageBoxW(nullptr, L"Could not locate Launch.exe.", L"Unified Engineering Workbench", MB_OK | MB_ICONERROR);
        return 1;
    }

    const std::filesystem::path launcher(std::wstring(module_path.data(), length));
    const std::filesystem::path app = launcher.parent_path() / L"UnifiedEngineeringWorkbench.exe";
    if (!std::filesystem::exists(app)) {
        MessageBoxW(nullptr,
                    L"UnifiedEngineeringWorkbench.exe is missing. Extract the complete package and try again.",
                    L"Unified Engineering Workbench", MB_OK | MB_ICONERROR);
        return 1;
    }

    std::wstring command_line = L"\"" + app.wstring() + L"\"";
    STARTUPINFOW startup{};
    startup.cb = sizeof(startup);
    PROCESS_INFORMATION process{};
    if (!CreateProcessW(app.c_str(), command_line.data(), nullptr, nullptr, FALSE, 0, nullptr,
                        launcher.parent_path().c_str(), &startup, &process)) {
        const DWORD error = GetLastError();
        const std::wstring message = L"The workbench could not start (Windows error " + std::to_wstring(error) + L").";
        MessageBoxW(nullptr, message.c_str(), L"Unified Engineering Workbench", MB_OK | MB_ICONERROR);
        return static_cast<int>(error);
    }
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
    return 0;
}
