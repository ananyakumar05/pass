#!/bin/sh
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
compiler=${CXX:-c++}
build_dir=$(mktemp -d "${TMPDIR:-/tmp}/uew-tests.XXXXXX")
trap 'rm -rf "$build_dir"' EXIT HUP INT TERM

cd "$repo_root"
core_sources="src/backend/geometry/geometry_parser.cpp src/backend/hardware/mock_adapters.cpp src/backend/neural_network/backprop.cpp src/backend/performance/batch_runner.cpp src/backend/thermal/thermal_solver.cpp"

for test_name in thermal geometry performance backprop hardware; do
    case "$test_name" in
        backprop) test_source=tests/neural_network/backprop_tests.cpp ;;
        *) test_source="tests/${test_name}/${test_name}_tests.cpp" ;;
    esac
    # Intentional word splitting: each listed file is a separate compiler argument.
    # shellcheck disable=SC2086
    "$compiler" -std=c++17 -Wall -Wextra -Wpedantic -pthread -Isrc/backend $core_sources "$test_source" -o "$build_dir/${test_name}_tests"
    "$build_dir/${test_name}_tests"
done
