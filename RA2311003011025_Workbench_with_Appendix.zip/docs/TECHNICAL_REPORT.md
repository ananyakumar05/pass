# Unified Engineering Workbench

**Assessment technical report**  
**Platform verified:** macOS arm64, Apple Clang 21, Qt 5.15.2  
**Scope:** verified prototype status as of 2 November 2026

## 1. Design and architecture

The workbench keeps numerical and file-processing logic in a Qt-independent C++17 core. The Qt Widgets frontend provides dashboard, geometry, thermal, performance, hardware, neural-network, and results views. Geometry parsing and longer computations run asynchronously through QtConcurrent so the interface can continue processing events. The core owns parsing, finite-element assembly, deterministic workload generation, thread execution, gradient calculations, and device simulation. The frontend owns controls, presentation, charts, and CSV export.

The interface uses a lightweight projected Qt painter canvas for ASCII STL facets and temperature points. It provides rotate, pan, zoom, fit, a temperature legend, and selected-node details. It is a focused assessment viewer, not a production CAD renderer. Thermal and performance requests use the same C++ modules that are covered by the core tests. The hardware page clearly marks adapters as simulated.

The build files target C++17, Qt 5.15 Widgets/Concurrent, and CMake 3.20+. This host had Qt 5.15.2 and Apple Clang 21. The application compiled and linked with qmake after a machine-local SDK framework search-path adjustment. CMake could not be configured because it was not installed. Windows/MSVC has not been tested. See `DEPENDENCIES.md` and `README.md` for build and licensing details.

## 2. Geometry and result data

The C++ parser accepts structurally valid ASCII STL and the ordered CSV header `node_id,x_m,y_m,z_m,temperature_C`. It rejects empty or malformed input, non-finite values, and files above 16 MiB. The bundled tetrahedron is self-created, with coordinates intended as millimetres because STL has no units. The bundled nodal temperatures are explicitly synthetic and are not presented as an ANSYS export. Binary STL and native CAD/ANSYS project formats are outside scope.

The interface maps CSV nodes to a temperature-colored point cloud and exposes node inspection. It does not register points against mesh geometry. A Qt offscreen walkthrough captured both data views and the main module workflows, using the app's asynchronous import handlers and numerical backend. A later live macOS session also showed the four-triangle STL, five-node synthetic CSV, and their visible views; screenshots are included in `outputs/walkthrough/`.

## 3. Thermal finite-element analysis

The model is a steady one-dimensional rod with `L=1 m`, `A=1e-4 m^2`, `k=10 W/(m K)`, `q=10,000 W/m^3`, and prescribed endpoint temperatures `T(0)=100 C`, `T(L)=20 C`. Constant properties, steady state, and insulated lateral surfaces are assumed. The governing equation is `-d/dx(k A dT/dx)=q A`. For a uniform two-node linear element of length `h`, the element stiffness matrix is `Ke=(kA/h)[[1,-1],[-1,1]]` and the consistent element load is `fe=(qAh/2)[1,1]`. The implementation assembles the tridiagonal global system, applies both prescribed endpoint temperatures by eliminating boundary couplings, and solves with the Thomas algorithm. The numerical core has no UI dependency.

The analytical reference is `T_exact(x)=100-80x/L+[q/(2k)]x(L-x)`. At each element midpoint, the FE temperature is linearly interpolated from that element's two nodal values. For this uniform mesh, the quadratic exact solution is represented at the nodes and the linear midpoint interpolation error is `q h^2/(8k)`. The tests compare the computed maximum midpoint absolute error to the closed-form values and check endpoint temperatures to `1e-12 C`:

| Elements | Maximum midpoint error (C) |
|---:|---:|
| 10 | 1.25 |
| 20 | 0.3125 |
| 40 | 0.078125 |
| 80 | 0.01953125 |

Halving the element size reduces the error by four. The test suite also covers zero element count, zero conductivity, node/error vector sizes, analytical endpoint values, and a single-element mesh. The single-element case has no free interior row for boundary-coupling elimination; the solver therefore imposes both endpoint rows directly when only two nodes exist. A dedicated regression test protects this edge case. The C++ result generator writes nodal and midpoint CSV data plus labeled temperature and convergence SVG plots. A live macOS run displayed the same four midpoint errors in the UI. The derivation is recorded in `docs/calculations/thermal_fem.md`; CSV exports are included in `results/csv/` and as Numbers workbooks in `outputs/spreadsheets/`.

## 4. Parallel performance

The recorded command-line benchmark used fixed seed `20261102` to generate 500 independent cases of 10,000 elements each, varying positive conductivity and heat generation. Serial and bounded `std::thread` runs use identical cases and solver code; results remain in input order. The program warms up both paths, then records five measurements and reports medians, speedup, efficiency, and maximum temperature difference. Compilation, rendering, file loading, and output writing are excluded from the timed region. Separately, the candidate supplied a live UI screenshot and exported Numbers workbook for a 500-case, 1,000-element five-repeat run. Its host identity is not visible, so it is reported separately and not attributed to the identified command-line host.

| Run | Workers | Median time (ms) | Speedup |
|---|---:|---:|---:|
| Serial | 1 | 76.8932 | 1.00000 |
| Parallel | 1 | 80.3047 | 0.95752 |
| Parallel | 2 | 40.1229 | 1.91644 |
| Parallel | 3 | 27.8360 | 2.76237 |
| Parallel | 4 | 21.1054 | 3.64329 |

The command-line run above was recorded on an Apple M2 with 8 physical (4 performance plus 4 efficiency) and 8 logical cores and 8 GB RAM, using Apple Clang 21.0.0 with `-std=c++17 -O2 -DNDEBUG -Wall -Wextra -Wpedantic -pthread`. The live UI run used 500 cases x 1,000 elements and displayed median times of 10.4909 ms serial and 8.0225, 4.2765, 2.9766, and 2.3191 ms for 1–4 workers, with speedups 1.3077, 2.4532, 3.5245, and 4.5237. Its maximum temperature difference was 0 C. The screenshot does not establish the machine model. These are separate runs; timing results are host- and load-dependent. Launch-to-ready time was not measured.

## 5. Embedded-system design

The design covers a NUCLEO-F446RE microcontroller board, a Digilent Arty A7-35 FPGA board, and a Digilent JTAG-HS2 debug adapter. The integration note provides a labelled topology, connector/power/ground/voltage/interface assumptions, level-shifting guidance, JTAG signal ownership, a safe hookup sequence, and manufacturer references. It distinguishes the Arty's onboard J10 programming route from the external J8 header. A JTAG adapter is a target-referenced debug/programming interface, not a general-purpose compute board.

The C++ mock registry reports capabilities, connects/disconnects devices, emits simulated telemetry, and recovers from an injected timeout. No physical board was connected, no firmware was deployed, and no FPGA was programmed.

## 6. Backpropagation and verification

The neural module implements `h=tanh(wx+b)`, `y_hat=vh+c`, and `J=0.5(y_hat-y)^2` for the specified sample and initial values, without automatic differentiation. It calculates all four chain-rule gradients and applies a simultaneous update from the original parameter vector. Central finite differences use epsilon `1e-6`; the tests enforce absolute error `<=1e-5`. The 100-step C++ training CSV and log-scale SVG are included. Loss falls from `1.1825418190` to `1.7026224287e-20`.

Five assertion-based C++ test programs were rebuilt and run using `scripts/run_tests.sh`; thermal, geometry, performance, backpropagation, and hardware suites all passed. The timestamped compiler/test log is in `results/test_evidence/`. The offscreen UI walkthrough and candidate-provided live macOS screenshots and action log are in `outputs/walkthrough/`. The screenshots additionally show the thermal model page, calculation and training page, and explicitly simulated hardware adapter. Visual review found and corrected a thermal plot that clipped the 185 C model peak and a Reports list that duplicated rows after refresh.

## 7. Limitations and ownership

This repository is an assessment prototype, not a verified Windows submission. A relative-path Win32 launcher and PowerShell packaging handoff are present, but CMake configuration, Windows/MSVC compilation, Qt runtime deployment, the packaged `Launch.exe`, extracted-ZIP launch, and a clean-machine Windows run remain unverified because the environment is macOS arm64 and has no Windows toolchain. Candidate-provided live macOS screenshots show geometry imports, four-mesh thermal analysis, performance, backpropagation, and simulated adapter pages. These verify the shown interactions on this Mac only. The offscreen scripted walkthrough is not a Qt Test suite; user-driven cancellation and other native interactions remain unverified. Performance measurements are machine-specific, and the candidate-run screenshot does not identify the host hardware. Hardware remains simulated; no physical devices were tested.

Candidate ID: `RA2311003011025`. Total effort hours were not supplied. A candidate-provided handwritten calculation photo was appended to the report PDF after its initial generation. It records the forward pass, gradients, and final parameter values; the full substituted arithmetic for each update is not shown. The typed derivation guide remains in `docs/calculations/backprop_derivation.md`. The walkthrough includes both Qt offscreen renders and user-provided live macOS screenshots; none is a live Windows demo. Source code, examples, calculations, tests, and project documentation were created for this workspace. No external project code or datasets were incorporated. Qt and report-generation tool versions are disclosed in `DEPENDENCIES.md`; AI assistance and independent checks are recorded in `AI_USE_LOG.md`.
