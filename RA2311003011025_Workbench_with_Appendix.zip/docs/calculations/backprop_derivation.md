# Handwritten appendix: one-sample backpropagation

Use this compact derivation as a guide for a handwritten appendix of no more than two pages. It is a mathematical guide only; no handwritten scan or submission is claimed complete.

Given `x = 1`, `y = 2`, `w = 0.5`, `b = 0`, `v = 1`, `c = 0`, and `eta = 0.1`:

```text
z = wx + b = 0.5
h = tanh(z) = 0.4621171573
y_hat = vh + c = 0.4621171573
e = y_hat - y = -1.5378828427
J = 0.5 e^2 = 1.1825418190
```

The local derivatives are

```text
dJ/dy_hat = e
dh/dz = 1 - h^2
dy_hat/dv = h                    dy_hat/dc = 1
dz/dw = x                       dz/db = 1
```

Applying the chain rule:

```text
dJ/dv = e h
dJ/dc = e
dJ/dw = e v (1 - h^2) x
dJ/db = e v (1 - h^2)
```

At the initial parameters:

```text
dJ/dw = -1.2094644752
dJ/db = -1.2094644752
dJ/dv = -0.7106820475
dJ/dc = -1.5378828427
```

Use all four gradients from these original values for one simultaneous update:

```text
w_new = 0.5 - 0.1(-1.2094644752) = 0.6209464475
b_new = 0.0 - 0.1(-1.2094644752) = 0.1209464475
v_new = 1.0 - 0.1(-0.7106820475) = 1.0710682047
c_new = 0.0 - 0.1(-1.5378828427) = 0.1537882843
```

All initial gradients are negative, so subtracting them increases the corresponding parameters. Locally, moving in that direction raises the prediction toward the target and reduces squared error. C++ central finite differences with epsilon `1e-6` check each initial gradient to absolute error `<= 1e-5`; the implementation does not use automatic differentiation.

The C++ training history applies the same learning rate for 100 further updates. The loss drops from `1.1825418190` at step 0 to `1.7026224287e-20` at step 100. The plotted vertical axis is logarithmic so the full decline is visible.
