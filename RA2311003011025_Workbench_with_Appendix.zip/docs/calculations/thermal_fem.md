# Thermal FEM: formulation and current verification

## Model

The assignment rod has length `L = 1 m`, area `A = 1e-4 m^2`, conductivity `k = 10 W/(m K)`, uniform heat generation `q = 10,000 W/m^3`, with `T(0) = 100 C` and `T(L) = 20 C`. The lateral surface is insulated, properties are constant, and the state is steady. The one-dimensional equation is

```text
-d/dx(k A dT/dx) = q A
```

For a uniform element of length `h`, the two-node linear element contributes

```text
Ke = (k A / h) [ [ 1, -1 ], [ -1, 1 ] ]
fe = (q A h / 2) [ 1, 1 ]
```

The implementation assembles these contributions into a tridiagonal global system and imposes the two prescribed temperatures by eliminating boundary couplings. It solves the resulting system with the Thomas algorithm. The core has no UI dependency.

## Analytical verification

The reference solution used is

```text
T_exact(x) = 100 - 80 x/L + [q/(2k)] x (L-x)
```

At each element midpoint, the FE value is interpolated from that element's two nodal values. Since the exact solution is quadratic and its nodal values are represented by the linear FE solution, the midpoint error for a uniform mesh is `q h^2/(8 k)`. The following values are the closed-form expectations; the test compares the computed maximum midpoint errors against them.

| Elements | Maximum midpoint absolute error (C) |
|---:|---:|
| 10 | 1.25 |
| 20 | 0.3125 |
| 40 | 0.078125 |
| 80 | 0.01953125 |

Each halving of element length reduces this error by a factor of four. Nodal boundary values are checked to `1e-12 C`. The executable test also checks zero element count, zero conductivity, node/error vector sizes, analytical endpoint values, and a single-element mesh.

## Debugging insight

Reviewing the prescribed-temperature elimination exposed a single-element edge case: there is no free interior row to adjust, and sequentially overwriting boundary rows could otherwise erase the coupling needed by the other prescribed node. The solver now skips interior-row elimination when there are only two nodes and imposes both endpoint rows directly. A dedicated one-element test protects that case.

## Current evidence and remaining work

The solver and tests were compiled with Apple Clang 21 using `-std=c++17 -Wall -Wextra -Wpedantic`; the test executable printed `thermal tests passed`. `tools/thermal_results.cpp` runs the C++ solver for the four required meshes and emits `results/csv/thermal_fem_results.csv`, `results/plots/thermal_fem_temperature.svg`, and `results/plots/thermal_fem_convergence.svg`. The FE plot uses nodal interpolation and shows the analytical curve. CMake remains unverified because CMake is unavailable on this host. No Windows packaging claim is made.
