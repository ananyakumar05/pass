# Assignment implementation plan

The official three-page assignment PDF is authoritative. The master prompt is a broader planning aid; where it differs, the PDF requirements below take precedence. Target effort is 40-50 hours over 15 calendar days, so prioritize a small tested prototype over production-scale breadth.

## Requirement-by-requirement plan

| Area | Required outcome | Planned implementation and evidence |
|---|---|---|
| A. Interface/backend | One coherent Geometry, Thermal Analysis, Performance, Hardware interface; validation, progress/status, errors, export, responsive work and safe completion; separated C++ core | Qt Widgets desktop shell over independent C++17 core. Run compute off the UI thread, report status/errors, export CSV. Focused core tests and documented workflows. |
| A. One-click delivery | Windows 11 x64 `Launch.exe`; offline, no install/admin/terminal; lawful runtime bundle; one-action editor configuration; separate CMake build guide | Windows packaging scripts and relative-path launcher. Verify extraction and launch on Windows 11 x64. Include editor extension prerequisite and packaging licenses. Current Mac environment cannot prove this gate. |
| B. Geometry/results | Existing ASCII STL and ANSYS nodal CSV schema; interactive triangle mesh and colored 3D points; legend, units, node inspection; strict C++ validation and sample provenance | C++ parsers with valid/invalid/empty/non-finite tests. Lightweight projected Qt canvas for rotate/pan/zoom/fit and point inspection. Add self-created small STL and explicitly synthetic temperature CSV, with units, provenance, schema and tested-size limit. |
| C. Thermal FEM | Specified 1D rod, two-node linear elements, assembled stiffness/load, fixed endpoint temperatures, 10/20/40/80 elements; midpoint interpolated error against analytical solution; plots and CSV | C++17 FEM module; independent analytical reference and convergence tests. Export nodal/element midpoint data and error summary. Plot numerical/analytical curves and convergence with labeled units. Document assumptions, equations, boundary conditions, and one real debugging insight. |
| D. Parallel work | Fixed-seed positive k/q batches; serial and bounded C++ worker execution; deterministic ordering; 1-4 workers capped by logical CPUs; five repeats/median; agreement <= 1e-8 C | Shared solver/input cases in both modes. Exclude I/O, rendering, compilation; warm-up; record CPU/core/RAM/compiler/flags/workload, speedup/efficiency and launch-to-ready separately. Only report measurements actually produced; disclose single-CPU or platform constraints. |
| E. Embedded design | MCU, FPGA and JTAG adapter; labeled block diagram and table for power/ground/voltage/level shifting/connectors/host/JTAG ownership/pin assumptions; C++ discovery/capabilities/connect/disconnect/telemetry mocks; recoverable failure | Safe, explicitly simulated adapters and UI states. Document device-specific assumptions, JTAG's debugging role, safe integration sequence, and no physical testing claim. No physical board/PCB/firmware is required. |
| F. Backprop | Exact single-sample model, chain-rule derivation and numerical values, simultaneous first update, finite differences (epsilon 1e-6, error <=1e-5), 100-step loss plot | Hand-coded C++ forward/gradient/update (no autodiff), central-difference tests, loss CSV/plot. Provide a clear derivation for the candidate to handwrite in at most two pages; do not claim a handwritten scan exists. |
| Submission | ZIP contents, README, <=6-page report plus handwritten appendix, AI log, ownership statement, dependencies/licenses, Git bundle/history, 3-5 min video or timestamped screenshot walkthrough with logs | Generate only from verified build and run evidence. AI log records this tool/model where available, representative prompts/outputs, edits and validation, plus a deliberate challenge test. Do not invent user actions, test runs, benchmarks or screenshots. |

## Phases, complexity and gates

| Phase | Work | Complexity | Exit evidence |
|---|---|---:|---|
| 1 | Inspect specification/environment; establish structure and architecture | Low | Requirement map, architecture, verified folder/layout and recorded prerequisites/limits |
| 2 | C++17/CMake foundation and test harness | Medium | Configure/build on available platform; one smoke test executed |
| 3 | Thermal FEM and analytical verification | High | Builds; assembly, boundary, midpoint error, convergence tests pass; raw results generated |
| 4 | STL/CSV parsing and 3D visualization | High | Positive and negative parser tests; interactive viewer run and examples documented |
| 5 | Serial/parallel batch workload and benchmarking | High | Agreement tests; reproducible measurement protocol and actual five-run medians |
| 6 | Backpropagation and finite-difference verification | Medium | Gradient/update tests, finite-difference bounds, 100-step loss data/plot |
| 7 | Embedded mocks and design documents | Medium | Adapter behavior/recovery tests, diagram and interface table |
| 8 | Frontend workflows and presentation | High | Responsive module workflows and actionable validation/status |
| 9 | Frontend/core integration | High | End-to-end requests, safe worker completion/cancellation and CSV export |
| 10 | Full regression and fixes | High | All recorded tests executed; actual outcomes captured |
| 11 | Results, report and demonstration walkthrough | Medium | Reproducible raw data, labeled plots, report, AI/ownership logs, timestamped evidence |
| 12 | Windows packaging and standalone verification | High | Extracted ZIP opens with `Launch.exe` on Windows 11 x64 without setup |

Recommended order follows the assignment, with early effort on C++ core and thermal verification because they are shortlist gates. The UI can be a lean desktop workflow rather than a production CAD suite. A full implementation likely requires the assignment's 40-50 hour target; this workspace session does not establish that time has elapsed.

## Stack and prerequisites

- **C++17 core and Qt Widgets/Concurrent frontend**: cross-platform native desktop, offline launch, and clear separation between domain logic and UI. Do not link Qt into the core. This host provides Qt 5.15.2, so the implemented UI targets Qt 5.
- **CMake**: source build and platform-specific packaging; record a pinned minimum version and Qt version once available.
- **Apple Clang 21** is visible here and can compile C++17, but it targets macOS arm64. Windows packaging requires Windows x64 compiler/toolchain and runtime validation.
- The available qmake installation is Qt 5.15.2. The UI builds with it, but CMake is not on PATH and the CMake project is unverified.
- **Git 2.50.1** is available. The current project directory was initially empty and not a Git repository.
- Windows 11 x64 verification, CPU/RAM reporting for benchmarks, and an output-identifying candidate ID are prerequisites for final evidence/packaging. Do not substitute host estimates or invented hardware data.

## Phase 1 verification record

- Read all three pages of the official PDF and the full master prompt.
- Inspected the current workspace: empty except for `work/` and `outputs/`; no existing source project or repository found.
- Confirmed macOS arm64 and Apple Clang 21; confirmed Git 2.50.1.
- `cmake` and `pdftotext` were unavailable on PATH. No Windows runtime or `Launch.exe` can be verified from this host.
- Created the planned module/documentation directory tree, architecture documents, and initial Git repository.

## Implementation progress after Phase 1

- **Phase 2 (implemented with build-system limitation):** added CMake 3.20+ and qmake C++17 application/core targets. CMake could not be run because it is absent. The Qt application was compiled and linked using available qmake/Qt 5.15.2; a machine-local SDK search-path workaround was needed.
- **Phase 3 (implemented):** added two-node linear FEM assembly, consistent element load, endpoint temperature imposition, Thomas tridiagonal solution, analytical solution evaluation, midpoint interpolation errors, and tests. `tools/thermal_results.cpp` generated the required nodal/midpoint data CSV, temperature plot, and convergence plot for 10/20/40/80 elements. The output contains errors 1.25, 0.3125, 0.078125, and 0.01953125 C.
- **Actual build/test evidence:** `./scripts/run_tests.sh` compiled the five C++ test programs with Apple Clang 21 and all reported `passed`. Timestamped logs are stored in `results/test_evidence/`. `git diff --check` was clean at the most recent reviewed changes.
- **Phase 4 (implemented; offscreen captures reviewed):** added strict ASCII STL and nodal-temperature CSV parsers, malformed/empty/non-finite tests, and the 16 MiB ceiling. Bundled samples identify units and provenance. The UI includes an interactive projected canvas, color scale, node inspection, and rotate/pan/zoom/fit controls; screenshots exercise asynchronous import handlers, but native display interaction could not be checked.
- **Phase 5 (implemented):** added fixed-seed varied workloads, serial and bounded `std::thread` execution with ordered results, five-repetition median measurements, speedup/efficiency, and a benchmark CLI. Raw measurements and a UI comparison chart are present. The recorded run used 500 cases x 10,000 elements and observed 0 C maximum serial/parallel difference. Launch-to-ready was not measured.
- **Phase 6 (calculation and verification implemented):** added the hand-coded tanh-regression forward pass, analytical gradients, simultaneous update, and 100-step training history. Central finite-difference tests use epsilon `1e-6` and enforce absolute error `<=1e-5`. Generated `results/csv/backprop_training.csv` and labeled log-scale `results/plots/backprop_loss.svg`; the derivation and numerical values are in `docs/calculations/backprop_derivation.md`. A handwritten scan is intentionally not claimed.
- **Phase 7 (mocks/design implemented):** added C++ mock MCU, FPGA, and JTAG adapter discovery/capability/connect/disconnect/telemetry plus a recoverable timeout and retry. Added a labeled block diagram, representative-device interface/voltage table, safe integration sequence, and vendor-manual references. `hardware_tests` passed. No physical hardware was connected or tested.
- **Phase 8 (desktop frontend implemented; offscreen captures reviewed):** added a Qt 5.15 main window with overview, geometry viewer, thermal analysis, performance, hardware integration, neural network, and reports pages. Geometry parsing and numerical workloads run asynchronously via QtConcurrent. The UI includes file validation, status/error displays, thermal and loss plots, benchmark charts, node inspection, mock device controls, and CSV export. The mesh view uses a lightweight projected Qt painter canvas rather than a production OpenGL renderer. The app compiled and linked. The Qt offscreen walkthrough captured module pages; normal window display is unavailable on this host.
- **Regression:** the five test programs (`thermal_tests`, `geometry_tests`, `performance_tests`, `backprop_tests`, `hardware_tests`) were rebuilt and all reported `passed`. The walkthrough also ran geometry imports, all four FEM meshes, a five-repeat UI benchmark, simulated hardware timeout/recovery/telemetry, neural training, and results navigation. It exposed a clipped thermal chart (axis capped at 100 C) and duplicate/overlapping result rows after refresh; both were corrected and recaptured. Timestamped screenshots/log are in `outputs/walkthrough/`.
- **Build/packaging limits:** CMake could not be run because it is absent. The GUI was built with the available qmake/Qt 5.15.2 after a local SDK framework search-path workaround. That host-specific invocation was not added to tracked project files. Windows 11 x64 and `Launch.exe` packaging are unavailable here and remain unverified.
- **Phase 9 (integrated with remaining gaps):** module pages call the C++ core; geometry loading and long computations use QtConcurrent and report results/errors. CSV export is wired for thermal, performance, and neural results. The scripted offscreen walkthrough exercises the handlers and workflows. User-driven cancellation and Qt Test assertions for window/widget behavior are not implemented.
- **Phase 10 (core tests passed; offscreen walkthrough complete):** the five assertion-based test suites were freshly built and passed. The capture tool exercised geometry imports, FEM, a small UI benchmark, simulated hardware failure/recovery, neural training, and results navigation. Screenshots were visually reviewed. Native display and Windows behavior remain unverified.
- **Phase 11 (prototype materials prepared):** generated FEM and neural result CSVs/plots; retained actual benchmark CSV; added timestamped test and screenshot evidence, dependency record, report source/PDF, README, AI-use and ownership notes, and Git bundle/commit log. No candidate-created handwritten pages are claimed.
- **Phase 12 (blocked by host requirements):** no Windows 11 x64 toolchain, runtime deployment utilities, or display/Windows machine are available. `Launch.exe`, Qt DLL packaging, extracted ZIP launch, and clean-machine verification remain outstanding. The delivered source archive must not be represented as satisfying the one-click launch gate.
