# Embedded-system integration design

This design is a documentation-level integration plan plus C++ mock adapters. No board was connected or tested. The model uses a NUCLEO-F446RE MCU board, Digilent Arty A7-35 FPGA board, and Digilent JTAG-HS2 adapter as representative devices. Check the exact board revision and manufacturer documentation before wiring.

## Host and device topology

```mermaid
flowchart LR
  Host[Windows host<br/>Unified Engineering Workbench]
  MCU[NUCLEO-F446RE<br/>MCU + ST-LINK]
  FPGA[Arty A7-35<br/>Artix-7 FPGA]
  JTAG[JTAG-HS2<br/>debug/program adapter]
  Host -- USB / virtual COM --> MCU
  Host -- USB J10 / on-board JTAG-UART --> FPGA
  Host -- USB micro-AB --> JTAG
  JTAG -- 6-pin target cable / J8 --> FPGA
  MCU -. optional 3.3 V GPIO link .- FPGA
```

The `JTAG-HS2 -> FPGA J8` path uses the external adapter. Use either that path or the Arty's onboard `J10` USB-JTAG path for a programming session; the host/application must not pretend that one enumerated USB device is the other. The optional MCU-to-FPGA GPIO link is a separate board-to-board interface, not part of the JTAG chain.

## Interface and voltage table

| Device/path | Connector/signals | Power and reference | Signal ownership and assumptions |
|---|---|---|---|
| Host to NUCLEO-F446RE | ST-LINK USB Mini-B; virtual COM for application messages | USB provides board input; board exposes nominal 3.3 V and 5 V rails | Host USB carries transport; ST-LINK owns the board's debug link. The board's PA13/PA14 are shared with SWD on the supported board configuration; do not allocate them as ordinary GPIO without checking the solder-bridge/board revision. |
| Nucleo Arduino power header CN6 | Pin 2 IOREF, pin 3 RESET, pin 4 +3.3 V, pin 5 +5 V, pins 6/7 GND, pin 8 VIN | 3.3 V IOREF; separate 5 V/VIN rails | These are distinct rails and functions. Do not connect VIN or +5 V to the FPGA's 3.3 V I/O. Only use pin-level MCU signal assumptions after checking the STM32F446 and board manual; do not assume every MCU pin tolerates 5 V. |
| Host to Arty A7-35 | Micro-AB USB `J10` for onboard USB-JTAG/UART, or host USB to external adapter | Board powered from USB 5 V or a suitable 7-15 V input per its manual | J10 is the board's onboard JTAG/UART path. USB carries host communication, not a generic GPIO voltage domain. |
| Arty A7 standard Pmod JA | 2x6, 100-mil connector; pins 1-4 and 7-10 are logic, pins 6/12 are 3.3 V, pins 5/11 GND | 3.3 V VCC and ground | Pmod FPGA I/O is 3.3 V logic; do not drive above 3.4 V. Example JA pin map: 1=G13, 2=B11, 3=A11, 4=D12, 7=D13, 8=B18, 9=A18, 10=K16. For low-speed/general use, prefer standard JA over high-speed JB/JC, whose series protection positions are shunted. |
| JTAG-HS2 host side | USB 2.0 micro-AB | Adapter is host USB powered | Host sees a programming/debug cable. It does not execute the workbench's thermal or other general-purpose compute jobs. |
| JTAG-HS2 target side | Digilent 6-pin 100-mil header cable to Arty J8; signals TCK, TMS, TDI, TDO, GND, VDD/VREF | For this example, target VREF is Arty JTAG I/O reference at 3.3 V. HS2 signal reference must match the target JTAG voltage; its supported reference range is 1.8-5 V. Ground is common between adapter and target. | Adapter drives TCK/TMS/TDI; FPGA drives TDO. VREF is supplied/referenced from target; it is not a generic target power output. Confirm cable orientation and target header markings before connection. |
| Optional MCU-FPGA GPIO | Selected MCU GPIO to selected FPGA Pmod/Arduino-compatible signal plus GND | Nominal 3.3 V logic on both sides only after board/pin configuration is checked | No level shifter for verified 3.3 V-compatible pins. Add a direction-appropriate translator for a 5 V peripheral or any mismatched voltage domain. Never connect two power outputs together. |

The Arty also has onboard J10 USB-JTAG circuitry, while J8 is the external programmer header. The HS2 is a target-specific debug/programming interface. It shifts USB control into JTAG target signals and provides target-referenced I/O. It is not interchangeable with the MCU board or FPGA: it has no general-purpose user compute resources or standalone workload execution role.

## Safe integration sequence

1. Identify exact board variants/revisions and read their pin tables/schematics.
2. Power the MCU and FPGA from their specified USB or regulated supplies independently; do not cross-connect their 5 V/VIN power outputs.
3. With power removed, connect only the intended JTAG signals, target reference, and ground. Verify orientation, target VREF, and that no second probe is driving the same lines.
4. For Arty, select either onboard J10 or external HS2 at J8 for the programming session. Confirm the board's target rail and tool detection before any programming operation.
5. For optional GPIO links, verify both pin assignments and logic levels first; add a level translator whenever compatibility is not documented.
6. Start with low-speed, low-energy I/O checks. Disconnect power before changing wiring. Monitor for heating, unexpected supply current, or signal contention.

## Simulation boundary

The C++ adapters expose device discovery, capabilities, connection state, simulated telemetry, disconnection, and an injected recoverable timeout. Strings and states are marked simulated. They do not enumerate real USB devices, read real sensors, drive JTAG, configure an FPGA, or claim physical testing.

## Manufacturer references

- [ST UM1724, STM32 Nucleo-64 user manual](https://www.st.com/resource/en/user_manual/dm00105823.pdf) documents NUCLEO-F446RE connector pin assignments, power options, and shared SWD pins.
- [Digilent Arty A7 reference manual](https://digilent.com/reference/programmable-logic/arty-a7/reference-manual) documents J10/J8 programming paths, Pmod voltage and pin assignments, and the board's power inputs.
- [Digilent JTAG-HS2 reference manual](https://digilent.com/reference/_media/reference/programmers/jtag-hs2/jtag-hs2_rm.pdf?rev=1614279128) documents the 6-pin 100-mil target connection, target-referenced voltage range, USB host interface, and signal buffer behavior.
