# Geometry and temperature data examples

## ASCII STL example

`data/geometry/example_tetrahedron_ascii.stl` is a small self-created tetrahedron with four ASCII facets. STL does not carry a unit declaration; this example's coordinates are intended as millimetres (a 1 mm edge). The file is synthetic and is not copied from a CAD package or external source. Its parser accepts ASCII STL only; binary STL is outside the current scope.

## Nodal temperature CSV example

`data/thermal/example_synthetic_nodal_temperatures.csv` is self-created synthetic data for the required schema:

```text
node_id,x_m,y_m,z_m,temperature_C
```

Coordinates are metres and temperatures are degrees Celsius. It is an illustrative point set, not an ANSYS export. A real ANSYS CSV can be imported only when it has this exact column order and schema.

## Validation and limits

Both C++ file loaders reject files larger than 16 MiB before parsing. The geometry tests verify rejection of a sparse 16 MiB + 1 byte STL and parse both bundled examples. Parsers reject empty input, malformed structure/rows, and non-finite numeric values with contextual errors. The Qt interface includes a lightweight projected mesh/point-cloud canvas, color scale, rotate/pan/zoom/fit controls, and node selection. Interactive visual behavior could not be verified because this environment has no display server; this view is not a production CAD renderer.
