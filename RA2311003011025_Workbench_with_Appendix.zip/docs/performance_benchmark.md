# Multithreaded benchmark record

## Protocol

The C++ workload generator uses seed `20261102`; each generated case varies positive conductivity uniformly over `[1, 100] W/(m K)` and volumetric generation over `[100, 100000] W/m^3`. Serial and parallel modes use identical cases and the same thermal solver. Results stay in input order. The parallel worker count is capped by logical CPUs and case count.

Before timing, one serial batch and one one-worker parallel batch are run as warm-ups. Each reported mode then has five measured repetitions; the median is the middle sorted value. Timings use `steady_clock` around solving and result creation. File loading, rendering, compilation, and CSV writing are outside the timed region. Parallel timing includes worker creation/join overhead. `results/csv/performance_benchmark.csv` contains the raw five samples for serial and each worker count plus medians, speedup, efficiency, and agreement.

## Environment and workload

- CPU: Apple M2, 8 physical cores (4 performance + 4 efficiency cores).
- Logical CPUs: 8 reported by `std::thread::hardware_concurrency()`.
- RAM: 8 GB.
- Compiler: Apple Clang 21.0.0.
- Flags: `-std=c++17 -O2 -DNDEBUG -Wall -Wextra -Wpedantic -pthread`.
- OS/architecture: macOS arm64. This is not Windows performance evidence.
- Workload: 500 cases, 10,000 elements per case, seed `20261102`.
- Worker counts: 1, 2, 3, 4; all are within the reported logical CPU count.
- Launch-to-ready: not measured. A desktop UI is implemented, but the no-display host prevented a visible startup measurement. The offscreen process smoke check is startup evidence only, not a launch-to-ready measurement.

## Measured medians

These values were emitted by an actual run of the C++ benchmark executable in this workspace; they are not hardcoded into the program.

| Mode | Workers | Median (ms) | Speedup | Efficiency |
|---|---:|---:|---:|---:|
| Serial | 1 | 76.8932 | 1.00000 | 1.00000 |
| Parallel | 1 | 80.3047 | 0.95752 | 0.95752 |
| Parallel | 2 | 40.1229 | 1.91644 | 0.95822 |
| Parallel | 3 | 27.8360 | 2.76237 | 0.92079 |
| Parallel | 4 | 21.1054 | 3.64329 | 0.91082 |

The maximum serial/parallel nodal temperature difference was `0 C`, below the required `1e-8 C` tolerance. Parallel one-worker time being slower than serial reflects worker scheduling/setup overhead. Parallel scaling was favorable for this workload on this host; it is one machine/run record, not a general performance guarantee. Benchmark results can vary with machine load and thermal state.
